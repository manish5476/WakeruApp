/**
 * TripSplit Native - Main App Component
 * Entry point for the application
 */

import React from 'react';
import { View } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { NavigationContainer } from '@react-navigation/native';
import { ThemeProvider } from './src/design-system';
import { ToastContainer } from './src/design-system';
import { AppProvider } from './src/context/AppContext';
import RootNavigator from './src/navigation/RootNavigator';
import { ErrorBoundary } from './src/components/ErrorBoundary';

export default function App() {
  return (
    <ErrorBoundary>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <ThemeProvider initialTheme="light">
          <AppProvider>
            <NavigationContainer>
              <RootNavigator />
              <ToastContainer />
            </NavigationContainer>
          </AppProvider>
        </ThemeProvider>
      </GestureHandlerRootView>
    </ErrorBoundary>
  );
}
