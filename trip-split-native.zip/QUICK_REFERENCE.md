# Quick Reference Guide - TripSplit Native

## Essential Commands

```bash
# Installation
npm install
pnpm install
yarn install

# Development
npm start                # Start Metro bundler
npm run ios             # Run on iOS simulator
npm run android         # Run on Android emulator
npm run ios -- --device # Run on iOS device

# Build for Release
npm run build:ios       # Build iOS app
npm run build:android   # Build Android app

# Testing
npm test                # Run tests
npm run lint            # Run linter

# Cache Clearing
npm start -- --reset-cache
cd ios && pod install && cd ..
cd android && ./gradlew clean && cd ..
```

---

## Most Used Imports

```tsx
// Design System
import { 
  VStack, HStack, Box, Spacer,
  Text, Button, Card, Input,
  AppBar, ListItem, Select,
  Toast, Dialog, Modal,
  useTheme
} from '@/design-system';

// Utilities
import { useForm } from '@/utils/useForm';
import { Validator, validateForm } from '@/utils/validation';
import { useSwipe, useLongPress } from '@/utils/gestures';

// Services
import { useToast } from '@/services/toast.service';
import { storage } from '@/services/storage.service';

// Context
import { useApp } from '@/context/AppContext';

// React Native
import { View, Text as RNText, Pressable } from 'react-native';
import { useEffect, useState, useCallback } from 'react';
```

---

## Common Patterns

### Create a Screen

```tsx
import React, { useState } from 'react';
import { View } from 'react-native';
import { VStack, HStack, Text, Button, AppBar } from '@/design-system';
import { useTheme } from '@/design-system';

export const MyScreen = ({ navigation }: any) => {
  const { colors } = useTheme();
  const [loading, setLoading] = useState(false);

  return (
    <View style={{ flex: 1, backgroundColor: colors.surface }}>
      <AppBar
        title="Screen Title"
        leftAction={{
          icon: <Text>←</Text>,
          onPress: () => navigation.goBack(),
        }}
      />
      <VStack flex={1} padding="lg" gap="md">
        <Text variant="heading3">Content</Text>
        <Button label="Action" onPress={() => {}} />
      </VStack>
    </View>
  );
};
```

### Create a Form

```tsx
import { useForm } from '@/utils/useForm';
import { commonValidations } from '@/utils/validation';
import { VStack, Input, Button } from '@/design-system';
import { useToast } from '@/services/toast.service';

export const LoginForm = () => {
  const toast = useToast();
  
  const form = useForm({
    initialValues: { email: '', password: '' },
    validate: (values) => {
      const errors: any = {};
      if (!Validator.email(values.email)) {
        errors.email = 'Invalid email';
      }
      if (values.password.length < 6) {
        errors.password = 'Password too short';
      }
      return errors;
    },
    onSubmit: async (values) => {
      try {
        // API call
        toast.success('Logged in!');
      } catch (error) {
        toast.error('Login failed');
      }
    },
  });

  return (
    <VStack gap="md">
      <Input
        label="Email"
        placeholder="user@example.com"
        value={form.values.email.value}
        onChangeText={(v) => form.handleChange('email', v)}
        error={form.values.email.error}
      />
      <Input
        label="Password"
        placeholder="••••••••"
        secureTextEntry
        value={form.values.password.value}
        onChangeText={(v) => form.handleChange('password', v)}
        error={form.values.password.error}
      />
      <Button
        label="Login"
        onPress={form.handleSubmit}
        loading={form.isSubmitting}
      />
    </VStack>
  );
};
```

### Use Toast Notifications

```tsx
import { useToast } from '@/services/toast.service';

export const MyComponent = () => {
  const toast = useToast();

  const handleSuccess = () => {
    toast.success('Success message!');
  };

  const handleError = () => {
    toast.error('Error occurred', { duration: 5000 });
  };

  const handleWithAction = () => {
    toast.info('Undo action?', {
      action: {
        label: 'Undo',
        onPress: () => {
          // Undo logic
        },
      },
    });
  };

  return (
    <VStack gap="md">
      <Button label="Success" onPress={handleSuccess} />
      <Button label="Error" onPress={handleError} />
      <Button label="With Action" onPress={handleWithAction} />
    </VStack>
  );
};
```

### Switch Themes

```tsx
import { useTheme } from '@/design-system';

export const ThemeSwitcher = () => {
  const { theme, setTheme, availableThemes } = useTheme();

  return (
    <VStack gap="md">
      {availableThemes.map((t) => (
        <Button
          key={t}
          label={t}
          variant={theme === t ? 'primary' : 'outlined'}
          onPress={() => setTheme(t)}
        />
      ))}
    </VStack>
  );
};
```

### Store Data Persistently

```tsx
import { storage } from '@/services/storage.service';

// Set
await storage.setItem('user', { id: 1, name: 'John' });

// Get
const user = await storage.getItem('user');

// Remove
await storage.removeItem('user');

// Clear all
await storage.clear();

// Multi operations
await storage.multiSet({
  user: { id: 1 },
  theme: 'dark',
  preferences: { notifications: true },
});

const data = await storage.multiGet(['user', 'theme']);
```

### Add Gesture Detection

```tsx
import { useSwipe, useLongPress } from '@/utils/gestures';

export const GestureComponent = () => {
  const { handleTouchStart, handleTouchEnd } = useSwipe(
    () => console.log('Swipe left'),
    () => console.log('Swipe right'),
    () => console.log('Swipe up'),
    () => console.log('Swipe down')
  );

  const longPress = useLongPress({
    duration: 500,
    onLongPress: () => console.log('Long pressed'),
    onPress: () => console.log('Pressed'),
  });

  return (
    <Pressable
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onPressIn={longPress.onPressIn}
      onPressOut={longPress.onPressOut}
    >
      <Text>Touch me</Text>
    </Pressable>
  );
};
```

### Create a List

```tsx
import { FlatList } from 'react-native';
import { VStack, ListItem } from '@/design-system';

export const ItemList = () => {
  const items = [
    { id: 1, name: 'Item 1', description: 'Description 1' },
    { id: 2, name: 'Item 2', description: 'Description 2' },
  ];

  return (
    <FlatList
      data={items}
      keyExtractor={(item) => item.id.toString()}
      renderItem={({ item }) => (
        <ListItem
          title={item.name}
          subtitle={item.description}
          onPress={() => console.log('Pressed item', item.id)}
        />
      )}
    />
  );
};
```

### Use Dialog

```tsx
import { useState } from 'react';
import { Dialog, Button, VStack } from '@/design-system';

export const DialogExample = () => {
  const [showDialog, setShowDialog] = useState(false);

  return (
    <VStack gap="md">
      <Button
        label="Show Dialog"
        onPress={() => setShowDialog(true)}
      />
      <Dialog
        visible={showDialog}
        title="Confirm Action"
        message="Are you sure you want to delete?"
        actions={[
          {
            label: 'Cancel',
            onPress: () => setShowDialog(false),
            variant: 'outlined',
          },
          {
            label: 'Delete',
            onPress: () => {
              // Delete logic
              setShowDialog(false);
            },
            variant: 'primary',
          },
        ]}
      />
    </VStack>
  );
};
```

---

## Design Tokens Quick Reference

### Spacing Values
```tsx
SPACING.xs    // 4
SPACING.sm    // 8
SPACING.md    // 16
SPACING.lg    // 24
SPACING.xl    // 32
SPACING.2xl   // 48
// etc...
```

### Radius Values
```tsx
RADIUS.xs     // 4
RADIUS.sm     // 8
RADIUS.md     // 12
RADIUS.lg     // 16
RADIUS.xl     // 20
RADIUS.full   // 9999
```

### Color Usage
```tsx
const { colors } = useTheme();

colors.primary
colors.secondary
colors.surface
colors.surfaceVariant
colors.onSurface
colors.onSurfaceVariant
colors.error
colors.warning
colors.success
colors.info
```

---

## Available Themes

```tsx
const themes = [
  'light',          // Light theme
  'dark',           // Dark theme
  'amoled',         // AMOLED dark
  'glass-light',    // Glass light
  'glass-dark',     // Glass dark
  'ocean'           // Ocean blue
];

// Switch theme
const { setTheme } = useTheme();
await setTheme('dark');
```

---

## Common Validation Rules

```tsx
import { Validator, commonValidations } from '@/utils/validation';

// Individual validators
Validator.email('test@example.com')      // true/false
Validator.phone('1234567890')            // true/false
Validator.password('Abc123!@#')          // true/false
Validator.url('https://example.com')     // true/false
Validator.required('value')              // true/false
Validator.minLength('abc', 3)            // true/false
Validator.maxLength('abcd', 3)           // true/false
Validator.pattern('123', /^\d+$/)        // true/false
Validator.number('123')                  // true/false
Validator.integer(123)                   // true/false
Validator.range(50, 0, 100)              // true/false

// Pre-built rules
const emailRules = commonValidations.email();
const passwordRules = commonValidations.password();
const requiredRules = commonValidations.required('Name');
const phoneRules = commonValidations.phone();
```

---

## Debugging Tips

```tsx
// Log component renders
console.log('[v0] Component rendering with props:', props);

// Debug form state
console.log('[v0] Form values:', form.values);
console.log('[v0] Form errors:', form.values);

// Debug context
console.log('[v0] User:', user);
console.log('[v0] Theme:', theme);

// Network debugging
console.log('[v0] API Response:', response);
console.log('[v0] Error:', error);

// Performance
console.time('operation');
// code here
console.timeEnd('operation');
```

---

## File Locations Cheat Sheet

```
Components:      src/design-system/components/
Tokens:          src/design-system/tokens/
Hooks:           src/design-system/hooks/
Themes:          src/design-system/theme/
Services:        src/services/
Utils:           src/utils/
Context:         src/context/
Screens:         src/screens/
Navigation:      src/navigation/
App Root:        App.tsx
Config:          app.json, tsconfig.json
```

---

## Prop Cheat Sheet

### Button Props
```tsx
<Button
  label="Click me"
  variant="primary"        // primary, secondary, outlined, text, danger
  size="md"               // sm, md, lg
  onPress={() => {}}
  disabled={false}
  loading={false}
  width="100%"
/>
```

### Input Props
```tsx
<Input
  label="Name"
  placeholder="Enter name"
  value={value}
  onChangeText={setValue}
  error={error}
  icon={<Icon />}
  disabled={false}
/>
```

### VStack/HStack Props
```tsx
<VStack
  gap="md"
  padding="lg"
  paddingH="sm"
  paddingV="lg"
  align="center"
  justify="space-between"
  flex={1}
  width="100%"
/>
```

### Select Props
```tsx
<Select
  label="Choose"
  options={[
    { label: 'Option 1', value: '1' },
    { label: 'Option 2', value: '2' },
  ]}
  value={selected}
  onChange={setSelected}
  error={error}
  required={true}
/>
```

---

## TypeScript Typing

```tsx
// Component props
interface MyComponentProps {
  title: string;
  onPress?: () => void;
  disabled?: boolean;
  children?: ReactNode;
}

// Form values
interface LoginFormValues {
  email: string;
  password: string;
}

// API response
interface User {
  id: string;
  name: string;
  email: string;
}

// Hook return
interface UseFormReturn {
  values: FormState;
  handleChange: (field: string, value: any) => void;
  handleSubmit: () => Promise<void>;
  isSubmitting: boolean;
}
```

---

## Performance Tips

```tsx
// Use React.memo for expensive components
export const ExpensiveComponent = React.memo(MyComponent);

// Use useCallback for functions
const handlePress = useCallback(() => {
  // logic
}, [dependencies]);

// Use useMemo for expensive computations
const memoized = useMemo(() => {
  return expensiveCalculation(data);
}, [data]);

// Optimize lists with FlatList
<FlatList
  data={items}
  renderItem={renderItem}
  keyExtractor={keyExtractor}
  removeClippedSubviews={true}
  maxToRenderPerBatch={10}
/>
```

---

**Happy coding! Reference this guide whenever you need quick help.** 🚀
