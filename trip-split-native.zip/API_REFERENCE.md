# TripSplit Design System - API Reference

## Components

### Box
Flexible layout component built on React Native View.

```tsx
import { Box } from './src/design-system';

<Box
  padding="lg"           // xs, sm, md, lg, xl, xxl, xxxl
  paddingH="md"          // Horizontal padding
  paddingV="md"          // Vertical padding
  margin="md"            // Margin variants
  marginH="md"           // Horizontal margin
  marginV="md"           // Vertical margin
  gap="md"               // Gap between children
  flexDirection="row"    // row | column
  alignItems="center"    // flex-start | center | flex-end | stretch
  justifyContent="space-between"
  flex={1}
  borderRadius="md"      // xs, sm, md, lg, xl, xxl, full
  bg={colors.surface}    // Background color
  borderWidth={1}
  borderColor={colors.border}
  opacity={0.5}
>
  {children}
</Box>
```

### Text
Semantic typography component.

```tsx
import { Text } from './src/design-system';

<Text
  variant="bodyLarge"    // 14 variants available
  color={colors.text}    // Any color string
  align="left"           // left | center | right | justify
  numberOfLines={2}      // Line clamp
  weight="semibold"      // light | regular | medium | semibold | bold
  italic
  uppercase
  lowercase
  capitalize
  opacity={0.8}
  onPress={() => {}}
>
  Text Content
</Text>
```

**Typography Variants:**
- displayLarge, displaySmall
- headingLarge, headingMedium, headingSmall
- titleLarge, titleMedium, titleSmall
- bodyLarge, bodyMedium, bodySmall
- labelLarge, labelSmall

### Button
Interactive button component.

```tsx
import { Button } from './src/design-system';

<Button
  onPress={() => {}}
  variant="primary"      // primary | secondary | outline | ghost | tertiary
  size="md"             // sm | md | lg
  disabled={false}
  loading={false}
  icon={<Icon />}
  iconPosition="left"    // left | right
  fullWidth
  testID="my-button"
>
  Button Text
</Button>
```

### Card
Surface component with elevation or glass effect.

```tsx
import { Card } from './src/design-system';

<Card
  variant="elevated"     // elevated | filled | outlined | glass
  padding="lg"          // Spacing token
  borderRadius="lg"     // Radius token
  onPress={() => {}}    // Optional press handler
>
  {children}
</Card>
```

### Input
Text input field with validation.

```tsx
import { Input } from './src/design-system';

<Input
  label="Email"
  placeholder="Enter email"
  value={state}
  onChangeText={setText}
  error="Invalid email"
  hint="Use valid email format"
  icon={<Icon />}
  iconPosition="left"    // left | right
  disabled={false}
/>
```

### Badge
Small label component.

```tsx
import { Badge } from './src/design-system';

<Badge
  label="New"
  variant="primary"      // default | primary | secondary | success | warning | danger
  size="md"             // sm | md | lg
  icon={<Icon />}
/>
```

### FAB
Floating action button.

```tsx
import { FAB } from './src/design-system';

<FAB
  icon={<Icon />}
  onPress={() => {}}
  position="bottom-right" // bottom-right | bottom-left | bottom-center
  disabled={false}
/>
```

### Modal
Dialog overlay.

```tsx
import { Modal } from './src/design-system';

<Modal
  visible={isOpen}
  onClose={() => setOpen(false)}
  title="Dialog Title"
  animated={true}
  transparent={true}
>
  {children}
</Modal>
```

### Switch
Toggle switch.

```tsx
import { Switch } from './src/design-system';

<Switch
  value={isOn}
  onValueChange={setOn}
  variant="primary"      // primary | secondary | accent
  size="md"             // sm | md
  disabled={false}
/>
```

### Divider
Visual separator.

```tsx
import { Divider } from './src/design-system';

<Divider
  orientation="horizontal" // horizontal | vertical
  thickness={1}
  margin="md"            // Spacing token
/>
```

### Chip
Selection chip.

```tsx
import { Chip } from './src/design-system';

<Chip
  label="Filter"
  selected={false}
  onPress={() => {}}
  icon={<Icon />}
  onDelete={() => {}}    // Optional delete handler
/>
```

### Avatar
User profile picture.

```tsx
import { Avatar } from './src/design-system';

<Avatar
  source={{ uri: 'url' }}  // Optional image
  name="John Doe"          // For initials
  size="md"               // xs | sm | md | lg | xl
/>
```

### Skeleton
Loading placeholder.

```tsx
import { Skeleton } from './src/design-system';

<Skeleton
  width="100%"
  height={16}
  shape="rect"           // rect | circle
  borderRadius={4}
/>
```

### BottomSheet
Bottom panel.

```tsx
import { BottomSheet } from './src/design-system';

<BottomSheet
  visible={isOpen}
  onClose={() => setOpen(false)}
  title="Sheet Title"
  height="60%"           // number or string percentage
>
  {children}
</BottomSheet>
```

## Hooks

### useTheme
Access and manage theme.

```tsx
import { useTheme } from './src/design-system';

const {
  theme,                 // Current theme name
  colors,                // Current color palette
  isDark,                // Boolean for dark mode
  setTheme,              // Function to change theme
  availableThemes,       // Array of theme names
} = useTheme();
```

**Available Themes:**
- 'light'
- 'dark'
- 'amoled'
- 'glass-light'
- 'glass-dark'
- 'ocean'

### usePressAnimation
Button press animation.

```tsx
import { usePressAnimation } from './src/design-system/hooks/useAnimation';

const {
  onPressIn,      // Call in onPressIn
  onPressOut,     // Call in onPressOut
  animatedStyle,  // Apply to animated view
} = usePressAnimation();
```

### useFadeInAnimation
Fade in animation.

```tsx
import { useFadeInAnimation } from './src/design-system/hooks/useAnimation';

const {
  triggerAnimation,  // Start animation
  animatedStyle,     // Apply to view
  opacity,           // Shared value
} = useFadeInAnimation(duration);
```

### useSlideAnimation
Slide animation.

```tsx
import { useSlideAnimation } from './src/design-system/hooks/useAnimation';

const {
  triggerAnimation,  // Start animation
  animatedStyle,     // Apply to view
} = useSlideAnimation(
  'up',             // up | down | left | right
  50,               // Distance
  300               // Duration
);
```

### useRotationAnimation
Rotation animation.

```tsx
import { useRotationAnimation } from './src/design-system/hooks/useAnimation';

const {
  startRotation,  // Start animation
  animatedStyle,  // Apply to view
} = useRotationAnimation(duration);
```

### useScaleAnimation
Scale animation.

```tsx
import { useScaleAnimation } from './src/design-system/hooks/useAnimation';

const {
  triggerScale,   // Trigger scale up
  resetScale,     // Reset to original
  animatedStyle,  // Apply to view
} = useScaleAnimation(initialScale, targetScale, duration);
```

### useResponsive
Responsive design utilities.

```tsx
import { useResponsive } from './src/design-system/hooks/useResponsive';

const {
  width,           // Screen width
  height,          // Screen height
  isXS,            // < 480px
  isSM,            // 480-768px
  isMD,            // 768-1024px
  isLG,            // 1024-1280px
  isXL,            // >= 1280px
  isPortrait,      // Orientation check
  isLandscape,     // Orientation check
  isSmallDevice,   // < 375px
  isMediumDevice,  // 375-768px
  isLargeDevice,   // >= 768px
  breakpoints,     // All breakpoint values
} = useResponsive();
```

## Design Tokens

### Spacing
```tsx
import { SPACING } from './src/design-system';

SPACING.xs    // 4px
SPACING.sm    // 8px
SPACING.md    // 12px
SPACING.lg    // 16px
SPACING.xl    // 24px
SPACING.xxl   // 32px
SPACING.xxxl  // 48px
```

### Radius
```tsx
import { RADIUS } from './src/design-system';

RADIUS.xs     // 4px
RADIUS.sm     // 8px
RADIUS.md     // 12px
RADIUS.lg     // 16px
RADIUS.xl     // 24px
RADIUS.xxl    // 32px
RADIUS.full   // 999px
```

### Shadows
```tsx
import { SHADOWS } from './src/design-system';

SHADOWS.sm    // Subtle shadow
SHADOWS.md    // Medium shadow
SHADOWS.lg    // Large shadow
SHADOWS.xl    // Extra large shadow
```

### Opacity
```tsx
import { OPACITY } from './src/design-system';

OPACITY.disabled   // 0.5
OPACITY.hover      // 0.7
OPACITY.pressed    // 0.6
OPACITY.light      // 0.2
OPACITY.lighter    // 0.1
```

### Timing
```tsx
import { TIMING } from './src/design-system';

TIMING.fast        // 150ms
TIMING.normal      // 300ms
TIMING.slow        // 500ms
TIMING.slower      // 800ms
```

## Colors

### Color Palettes
```tsx
import {
  PRIMARY,      // Blue (Professional)
  SECONDARY,    // Purple (Creative)
  ACCENT,       // Emerald (Success)
  WARNING,      // Orange (Caution)
  DANGER,       // Red (Error)
  INFO,         // Blue (Information)
  NEUTRAL,      // Grays
} from './src/design-system';

PRIMARY[500]    // Mid-tone primary color
NEUTRAL[900]    // Darkest gray
```

### Theme Colors
```tsx
import { LIGHT_THEME, DARK_THEME } from './src/design-system';

// Use with useTheme instead
const { colors } = useTheme();
colors.background
colors.surface
colors.text
colors.primary
colors.danger
// etc...
```

## Typography

### Typography Variants
```tsx
import { TEXT_PRESETS, TYPOGRAPHY } from './src/design-system';

// In Text component
<Text variant="bodyLarge">Text</Text>

// Direct access
TYPOGRAPHY.headingLarge
TEXT_PRESETS.h1
```

### Fonts
```tsx
import { FONTS, FONT_WEIGHTS } from './src/design-system';

FONTS.INTER_REGULAR
FONTS.SPACE_GROTESK_BOLD
FONT_WEIGHTS.semibold
```

## Animation Presets

### Spring Configs
```tsx
import { SPRING_CONFIGS } from './src/design-system';

SPRING_CONFIGS.gentle     // Smooth
SPRING_CONFIGS.quick      // Fast
SPRING_CONFIGS.bouncy     // Playful
SPRING_CONFIGS.stiff      // Precise
SPRING_CONFIGS.molasses   // Very smooth
```

### Timing Presets
```tsx
import { TIMING_PRESETS } from './src/design-system';

TIMING_PRESETS.micro      // 100ms
TIMING_PRESETS.fast       // 200ms
TIMING_PRESETS.normal     // 300ms
TIMING_PRESETS.slow       // 500ms
TIMING_PRESETS.slower     // 800ms
TIMING_PRESETS.glacial    // 1200ms
```

## Theme System

### Available Themes
```tsx
import { AVAILABLE_THEMES } from './src/design-system';

// ['light', 'dark', 'amoled', 'glass-light', 'glass-dark', 'ocean']
```

### Theme Provider
```tsx
import { ThemeProvider } from './src/design-system';

<ThemeProvider initialTheme="light">
  {children}
</ThemeProvider>
```

## Type System

```tsx
import {
  SemanticColors,
  ThemeName,
  SpringConfig,
  TimingPreset,
  EasingFunction,
} from './src/design-system';

// Types available for TypeScript
```

## Complete Export List

```tsx
import {
  // Components
  Box, Text, Button, Card, Input, Badge, FAB, Modal,
  Switch, Divider, Chip, Avatar, Skeleton, BottomSheet,
  
  // Hooks
  useTheme, useResponsive,
  usePressAnimation, useFadeInAnimation, useSlideAnimation,
  useRotationAnimation, useScaleAnimation,
  
  // Theme
  ThemeProvider, ThemeContext, AVAILABLE_THEMES,
  
  // Tokens
  SPACING, RADIUS, SHADOWS, OPACITY, BORDER_WIDTH,
  ELEVATION, GLASS, TIMING, BREAKPOINTS, Z_INDEX,
  
  // Colors
  LIGHT_THEME, DARK_THEME, AMOLED_THEME,
  GLASS_LIGHT_THEME, GLASS_DARK_THEME, OCEAN_THEME,
  PRIMITIVES, NEUTRAL, PRIMARY, SECONDARY, ACCENT,
  WARNING, DANGER, INFO,
  
  // Typography
  FONTS, LINE_HEIGHTS, TYPOGRAPHY, TEXT_PRESETS,
  FONT_WEIGHTS, getTypography,
  
  // Animations
  SPRING_CONFIGS, TIMING_PRESETS, EASING_FUNCTIONS,
} from './src/design-system';
```

---

This is the complete API reference for TripSplit Native Design System.
