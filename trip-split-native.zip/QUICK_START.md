# TripSplit Native - Quick Start Guide

## 5-Minute Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Development
```bash
# Terminal 1: Start Metro bundler
npm start

# Terminal 2: Run on iOS
npm run ios

# OR Terminal 2: Run on Android
npm run android
```

### 3. Open the App
- iOS: Xcode simulator will open automatically
- Android: Android emulator will open automatically

### 4. Explore
- **Home Tab**: Dashboard with interactive demo
- **Components Tab**: Browse all components
- **Settings Tab**: Change themes (6 available!)

## What You Get

- ✅ 14 production-ready components
- ✅ 6 beautiful themes
- ✅ Full animation system
- ✅ Complete TypeScript setup
- ✅ Real working screens
- ✅ Theme switching with persistence

## Using the Design System

### Basic Component
```tsx
import { Box, Text, Button, useTheme } from './src/design-system';

export default function MyScreen() {
  const { colors } = useTheme();
  
  return (
    <Box padding="lg" bg={colors.background}>
      <Text variant="headingLarge">Title</Text>
      <Button onPress={() => alert('Clicked!')} variant="primary">
        Press Me
      </Button>
    </Box>
  );
}
```

### Access Theme
```tsx
import { useTheme } from './src/design-system';

export default function MyComponent() {
  const { colors, theme, setTheme, isDark } = useTheme();
  
  return (
    <Box bg={colors.surface}>
      <Text color={colors.text}>Current: {theme}</Text>
    </Box>
  );
}
```

### Use Animation
```tsx
import { usePressAnimation } from './src/design-system/hooks/useAnimation';
import Animated from 'react-native-reanimated';
import { Pressable } from 'react-native';

export default function AnimatedButton() {
  const { onPressIn, onPressOut, animatedStyle } = usePressAnimation();
  
  return (
    <Animated.View style={animatedStyle}>
      <Pressable onPressIn={onPressIn} onPressOut={onPressOut}>
        <Text>Press Me</Text>
      </Pressable>
    </Animated.View>
  );
}
```

## Available Themes

1. **light** - Professional light theme (default)
2. **dark** - Easy on the eyes dark theme
3. **amoled** - Optimized for OLED screens
4. **glass-light** - Frosted glass effect
5. **glass-dark** - Dark glass morphism
6. **ocean** - Cool blue palette

## Available Components

| Component | File | Variants |
|-----------|------|----------|
| Box | `components/Box.tsx` | - |
| Text | `components/Text.tsx` | 14 typography variants |
| Button | `components/Button.tsx` | primary, secondary, outline, ghost, tertiary |
| Card | `components/Card.tsx` | elevated, filled, outlined, glass |
| Input | `components/Input.tsx` | - |
| Badge | `components/Badge.tsx` | primary, secondary, success, warning, danger |
| FAB | `components/FAB.tsx` | - |
| Modal | `components/Modal.tsx` | - |
| Switch | `components/Switch.tsx` | primary, secondary, accent |
| Divider | `components/Divider.tsx` | horizontal, vertical |
| Chip | `components/Chip.tsx` | selectable |
| Avatar | `components/Avatar.tsx` | xs, sm, md, lg, xl |
| Skeleton | `components/Skeleton.tsx` | rect, circle |
| BottomSheet | `components/BottomSheet.tsx` | - |

## Common Tasks

### Create a New Screen
```tsx
// src/screens/MyScreen/MyScreen.tsx
import React from 'react';
import { ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Box, Text, useTheme, SPACING } from '../../design-system';

export default function MyScreen() {
  const { colors } = useTheme();
  
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView contentContainerStyle={{ padding: SPACING.lg }}>
        <Text variant="headingLarge">My Screen</Text>
      </ScrollView>
    </SafeAreaView>
  );
}
```

### Add Screen to Navigation
```tsx
// src/navigation/RootNavigator.tsx
import MyScreen from '../screens/MyScreen/MyScreen';

<Tab.Screen
  name="MyTab"
  component={MyScreen}
  options={{ title: 'My Tab' }}
/>
```

### Create a Reusable Component
```tsx
// src/components/MyButton.tsx
import { Button } from '../design-system';

export default function MyButton(props) {
  return (
    <Button variant="primary" fullWidth {...props} />
  );
}
```

## Project Structure Tip

- **src/design-system/** - Never modify (design system)
- **src/screens/** - Add your app screens here
- **src/components/** - Add reusable components
- **src/navigation/** - Modify navigation setup
- **App.tsx** - App entry point

## Design Token Access

```tsx
import {
  SPACING,
  RADIUS,
  SHADOWS,
  TIMING,
  BREAKPOINTS,
} from './src/design-system';

// Usage
<Box padding={SPACING.lg} borderRadius={RADIUS.md}>
```

## Debug Tips

### Check Current Theme
```tsx
const { colors, theme, isDark } = useTheme();
console.log('Current theme:', theme);
console.log('Is dark:', isDark);
```

### Inspect Colors
```tsx
const { colors } = useTheme();
console.log('Available colors:', colors);
```

### Test Responsive Layout
```tsx
import { useResponsive } from './src/design-system/hooks/useResponsive';

export default function MyComponent() {
  const { width, isSmallDevice, isMediumDevice, isLargeDevice } = useResponsive();
  
  return (
    <Box flex={isSmallDevice ? 1 : 0.5}>
      Responsive layout
    </Box>
  );
}
```

## Performance Tips

1. **Use memoization** for complex components
2. **Lazy load** heavy screens
3. **Use Reanimated** for 60fps animations
4. **Avoid inline objects** in styles
5. **Profile** with Flipper

## iOS/Android Differences

- Fonts load differently on iOS vs Android
- Shadow rendering varies (platform-specific in SHADOWS)
- Safe area handling is automatic
- Gesture responder system differs

## Troubleshooting

### "Module not found" error
```bash
npm install
# or
yarn install
```

### "Cannot find module" for design-system
Check that you're importing from the correct path:
```tsx
import { Button } from '../design-system';
// not
import { Button } from '@design-system';
```

### Animation not working
Make sure you've:
1. Installed react-native-reanimated
2. Added plugin to babel.config.js
3. Using Animated components properly

### Theme not persisting
AsyncStorage persistence happens automatically. If resetting:
```tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
await AsyncStorage.removeItem('@tripsplit_theme');
```

## Next Steps

1. Read **README.md** for comprehensive docs
2. Explore **src/screens/** for examples
3. Check **src/design-system/components/** for component API
4. Modify screens in **src/screens/** for your features
5. Add new screens as needed

## Resources

- [React Native Docs](https://reactnative.dev)
- [React Navigation Docs](https://reactnavigation.org)
- [Reanimated Docs](https://docs.swmansion.com/react-native-reanimated/)
- [TypeScript Docs](https://www.typescriptlang.org)

## Support

- Check comments in code
- Read inline documentation
- Refer to example screens
- Check component props (TypeScript autocomplete)

---

**Happy coding! 🚀**
