# Complete Component Inventory - TripSplit Native

## All 31 Components with Details

### LAYOUT COMPONENTS (4)

#### 1. **VStack**
- **Purpose**: Vertical stack layout
- **Props**: gap, padding, paddingH, paddingV, align, justify, flex, width, height
- **Usage**: `<VStack gap="md"><Item1 /><Item2 /></VStack>`
- **Features**: Auto spacing, flexbox, ref forwarding

#### 2. **HStack**
- **Purpose**: Horizontal stack layout
- **Props**: gap, padding, paddingH, paddingV, align, justify, flex, width, height
- **Usage**: `<HStack gap="sm"><Item1 /><Item2 /></HStack>`
- **Features**: Auto spacing, row direction, ref forwarding

#### 3. **Spacer**
- **Purpose**: Flexible spacing
- **Props**: flex
- **Usage**: `<Spacer flex={1} />`
- **Features**: Takes available space, useful for alignment

#### 4. **Box**
- **Purpose**: Base container component
- **Props**: All View props + design system props
- **Usage**: `<Box padding="lg"><Content /></Box>`
- **Features**: Flexible, ref forwarding, styled container

---

### NAVIGATION COMPONENTS (1)

#### 5. **AppBar**
- **Purpose**: Top navigation bar
- **Props**: title, subtitle, leftAction, rightActions, elevation, centered
- **Usage**: `<AppBar title="Home" leftAction={{icon, onPress}} />`
- **Features**: Safe area, elevation, icon actions, centered mode

---

### TEXT COMPONENTS (1)

#### 6. **Text**
- **Purpose**: Semantic text rendering
- **Props**: variant (14 types), weight, color, align, numberOfLines
- **Usage**: `<Text variant="heading2" color={colors.primary}>Title</Text>`
- **Features**: 16 variants, font weights, custom colors, ellipsis

---

### BUTTON COMPONENTS (1)

#### 7. **Button**
- **Purpose**: Interactive button
- **Props**: label, variant, size, onPress, disabled, loading, width
- **Usage**: `<Button label="Click" onPress={handlePress} />`
- **Features**: 5 variants, loading state, disabled state, custom width

---

### INPUT COMPONENTS (1)

#### 8. **Input**
- **Purpose**: Text input with validation
- **Props**: label, placeholder, error, hint, icon, disabled, required
- **Usage**: `<Input label="Email" placeholder="Enter email" />`
- **Features**: Error display, hint text, icon support, disabled state

---

### LIST COMPONENTS (1)

#### 9. **ListItem**
- **Purpose**: Standardized list row
- **Props**: title, subtitle, description, leftIcon, rightIcon, rightText, badge, selected, disabled
- **Usage**: `<ListItem title="John" subtitle="john@email.com" onPress={handlePress} />`
- **Features**: Icons, badges, selection, divider, disabled state

---

### CARD COMPONENTS (1)

#### 10. **Card**
- **Purpose**: Container with elevation/glass
- **Props**: variant (4 types), children, padding, style, onPress
- **Usage**: `<Card variant="glass"><Content /></Card>`
- **Features**: 4 variants (elevated, filled, outlined, glass), pressable

---

### BADGE COMPONENTS (1)

#### 11. **Badge**
- **Purpose**: Status indicator
- **Props**: label, variant, size, style
- **Usage**: `<Badge label="New" variant="primary" />`
- **Features**: 6 color variants, 3 sizes, custom styling

---

### AVATAR COMPONENTS (1)

#### 12. **Avatar**
- **Purpose**: User avatar
- **Props**: initial, image, size, backgroundColor
- **Usage**: `<Avatar initial="JD" size="lg" />`
- **Features**: Image or initial, 3 sizes, custom colors

---

### FAB COMPONENTS (1)

#### 13. **FAB**
- **Purpose**: Floating action button
- **Props**: icon, onPress, label, color, size
- **Usage**: `<FAB icon={<Icon />} onPress={handlePress} />`
- **Features**: Positioned absolutely, animated, custom size

---

### CHIP COMPONENTS (1)

#### 14. **Chip**
- **Purpose**: Selection chip
- **Props**: label, selected, onPress, onClose, icon, disabled
- **Usage**: `<Chip label="React" selected={true} onPress={toggleChip} />`
- **Features**: Selection state, close button, disabled mode

---

### SELECT/PICKER COMPONENTS (1)

#### 15. **Select**
- **Purpose**: Dropdown picker
- **Props**: label, placeholder, options, value, onChange, error, required
- **Usage**: `<Select options={items} value={selected} onChange={setSelected} />`
- **Features**: Modal picker, error display, required validation

---

### CHECKBOX COMPONENTS (1)

#### 16. **CheckboxGroup**
- **Purpose**: Multi-select checkboxes
- **Props**: label, options, value (array), onChange, error, required
- **Usage**: `<CheckboxGroup options={items} value={selected} onChange={setSelected} />`
- **Features**: Multiple selection, error display, disabled items

---

### RADIO COMPONENTS (1)

#### 17. **RadioGroup**
- **Purpose**: Single-select radio buttons
- **Props**: label, options, value, onChange, error, required
- **Usage**: `<RadioGroup options={items} value={selected} onChange={setSelected} />`
- **Features**: Single selection, descriptions, disabled items

---

### SWITCH COMPONENTS (1)

#### 18. **Switch**
- **Purpose**: Toggle switch
- **Props**: value, onValueChange, color, disabled
- **Usage**: `<Switch value={enabled} onValueChange={setEnabled} />`
- **Features**: Animated toggle, color customization

---

### DIVIDER COMPONENTS (1)

#### 19. **Divider**
- **Purpose**: Visual separator
- **Props**: vertical, color, thickness, style
- **Usage**: `<Divider />` or `<Divider vertical />`
- **Features**: Horizontal/vertical, color customization

---

### SKELETON COMPONENTS (1)

#### 20. **Skeleton**
- **Purpose**: Loading placeholder
- **Props**: width, height, animation, style
- **Usage**: `<Skeleton width={200} height={40} />`
- **Features**: Animated shimmer, custom dimensions

---

### MODAL COMPONENTS (2)

#### 21. **Modal**
- **Purpose**: Modal dialog overlay
- **Props**: visible, title, children, onDismiss, actions
- **Usage**: `<Modal visible={show} title="Confirm" onDismiss={() => setShow(false)} />`
- **Features**: Backdrop press, transparent overlay

#### 22. **BottomSheet**
- **Purpose**: Bottom drawer panel
- **Props**: visible, title, children, onDismiss, isDismissible
- **Usage**: `<BottomSheet visible={show}><Content /></BottomSheet>`
- **Features**: Slide from bottom, drag handle, dismissible

---

### NOTIFICATION COMPONENTS (1)

#### 23. **Toast** + **ToastContainer**
- **Purpose**: Toast notifications
- **Props**: message, type (success/error/warning/info), duration, action
- **Usage**: `const toast = useToast(); toast.success('Done!')` + `<ToastContainer />`
- **Features**: 4 types, auto-dismiss, action buttons, animation

---

### FEEDBACK COMPONENTS (1)

#### 24. **Dialog**
- **Purpose**: Alert dialog
- **Props**: visible, title, message, actions, icon, onDismiss, isDismissible
- **Usage**: `<Dialog visible={show} title="Confirm" actions={[{label, onPress}]} />`
- **Features**: Custom actions, icon support, scrollable content

---

### PROGRESS COMPONENTS (1)

#### 25. **ProgressBar**
- **Purpose**: Progress indicator
- **Props**: progress (0-100), label, size, color, animated
- **Usage**: `<ProgressBar progress={75} />`
- **Features**: 3 sizes, animated progress, custom colors

---

### STEPPER COMPONENTS (1)

#### 26. **Stepper**
- **Purpose**: Step indicator
- **Props**: steps, currentStep, orientation (horizontal/vertical), onStepPress
- **Usage**: `<Stepper steps={steps} currentStep={2} />`
- **Features**: Vertical/horizontal, completed states, click to jump

---

### ACCORDION COMPONENTS (1)

#### 27. **Accordion**
- **Purpose**: Collapsible sections
- **Props**: items, allowMultiple, style
- **Usage**: `<Accordion items={[{title, content}]} />`
- **Features**: Single/multi-expand, smooth animation, content types

---

### CAROUSEL COMPONENTS (1)

#### 28. **Carousel**
- **Purpose**: Swipeable carousel
- **Props**: items, height, showPagination, autoplay, autoplayInterval
- **Usage**: `<Carousel items={items} height={200} />`
- **Features**: Pagination dots, autoplay, snap to item

---

### TAB COMPONENTS (1)

#### 29. **Tabs**
- **Purpose**: Tab navigation
- **Props**: tabs, activeTab, onTabChange, variant (text/filled/outlined)
- **Usage**: `<Tabs tabs={tabs} activeTab={active} onTabChange={setActive} />`
- **Features**: 3 variants, badges, scrollable, full width

---

### RATING COMPONENTS (1)

#### 30. **Rating**
- **Purpose**: Star rating
- **Props**: rating, maxRating, onRatingChange, size, readOnly, showText
- **Usage**: `<Rating rating={4.5} onRatingChange={setRating} />`
- **Features**: Interactive/read-only, sizes, decimal ratings

---

### LOADER COMPONENTS (1)

#### 31. **Loader**
- **Purpose**: Spinning loader
- **Props**: size (sm/md/lg), color, style
- **Usage**: `<Loader size="md" />`
- **Features**: 3 sizes, custom colors, smooth rotation

---

### EMPTY STATE COMPONENTS (1)

#### 32. **EmptyState**
- **Purpose**: Empty state placeholder
- **Props**: icon, title, message, image, action
- **Usage**: `<EmptyState title="No items" message="Add your first item" />`
- **Features**: Icon/image support, action button, centered layout

---

### TOUCHABLE COMPONENTS (1)

#### 33. **Touchable**
- **Purpose**: Consistent touch feedback
- **Props**: onPress, onLongPress, children, disabled, feedback (low/medium/high)
- **Usage**: `<Touchable onPress={handlePress}><Content /></Touchable>`
- **Features**: Opacity feedback, gesture handlers, disabled state

---

## Component Organization

### By Category
- **Layout**: 4 components
- **Navigation**: 1 component
- **Typography**: 1 component
- **Interactive**: 3 components (Button, Input, Card)
- **Display**: 6 components (Badge, Avatar, Chip, Divider, Skeleton, Carousel)
- **Forms**: 3 components (Select, CheckboxGroup, RadioGroup)
- **Feedback**: 2 components (Toast, Dialog)
- **Modals**: 2 components (Modal, BottomSheet)
- **Progress**: 2 components (ProgressBar, Stepper)
- **Complex**: 4 components (Accordion, Tabs, Rating, Loader)
- **Utility**: 2 components (Spacer, Touchable)
- **State**: 1 component (EmptyState)

### By Use Case

#### Forms & Input
- Input
- Select
- CheckboxGroup
- RadioGroup
- Switch

#### Lists & Collections
- ListItem
- Chip
- Avatar
- Badge

#### Display & Feedback
- Text
- Card
- Badge
- Toast
- Dialog
- ProgressBar
- Rating
- Loader

#### Layout & Structure
- VStack
- HStack
- Spacer
- Box
- Card
- AppBar

#### Navigation & Browsing
- Tabs
- Stepper
- Accordion
- Carousel
- AppBar

#### Modals & Overlays
- Modal
- BottomSheet
- Dialog
- Skeleton

---

## Component Props Summary

### Common Props Across All Components
- `style` - Custom style object
- `testID` - For testing
- `ref` - Forward ref support (most components)
- `key` - React key for lists

### Common Props for Interactive Components
- `disabled` - Disable interaction
- `onPress` - Handle press
- `onLongPress` - Handle long press

### Common Props for Form Components
- `label` - Field label
- `error` - Error message
- `required` - Mark as required
- `placeholder` - Input placeholder

### Common Props for Layout Components
- `padding` / `paddingH` / `paddingV` - Padding
- `gap` - Gap between items
- `align` - Alignment
- `justify` - Justification
- `flex` - Flex factor
- `width` / `height` - Dimensions

---

## Quick Reference Table

| Component | Category | Purpose | Key Props |
|-----------|----------|---------|-----------|
| VStack | Layout | Vertical layout | gap, padding, align |
| HStack | Layout | Horizontal layout | gap, padding, align |
| Box | Layout | Generic container | padding, style |
| Text | Typography | Text display | variant, color, weight |
| Button | Interactive | Clickable button | label, variant, onPress |
| Input | Form | Text input | label, placeholder, error |
| Select | Form | Dropdown | options, value, onChange |
| CheckboxGroup | Form | Multi-select | options, value, onChange |
| RadioGroup | Form | Single-select | options, value, onChange |
| Card | Display | Container | variant, children |
| ListItem | Display | List row | title, subtitle, icon |
| Badge | Display | Status indicator | label, variant |
| Avatar | Display | User image | initial, image, size |
| Toast | Feedback | Notification | message, type, duration |
| Dialog | Feedback | Alert dialog | title, message, actions |
| Modal | Modal | Full modal | title, children, visible |
| BottomSheet | Modal | Bottom drawer | title, children, visible |
| ProgressBar | Progress | Progress indicator | progress, size |
| Stepper | Progress | Step indicator | steps, currentStep |
| Tabs | Navigation | Tab navigation | tabs, activeTab |
| Accordion | Navigation | Collapsible | items, allowMultiple |
| Carousel | Navigation | Swipeable | items, height |
| Rating | Interactive | Star rating | rating, maxRating |
| Loader | Feedback | Loading spinner | size, color |
| EmptyState | Display | Empty placeholder | title, message, icon |
| Skeleton | Display | Loading placeholder | width, height |
| AppBar | Navigation | Top bar | title, actions |
| Chip | Display | Selection chip | label, selected |
| Divider | Display | Visual separator | vertical, color |
| Switch | Form | Toggle | value, onValueChange |
| Touchable | Interactive | Touch handler | onPress, children |

---

## Component Dependencies

```
Design System
├── Tokens (spacing, colors, radius, shadows)
├── Theme (ThemeProvider, useTheme)
├── Typography (FONTS, TYPOGRAPHY)
└── Animations (useAnimation, spring configs)

Core Components
├── Box → Design tokens, theme
├── Text → Typography system, theme
├── Button → VStack, HStack, Text, useAnimation
├── Card → Box, theme
└── Input → VStack, Text, theme

Layout Components
├── VStack → View, design tokens
├── HStack → View, design tokens
├── Spacer → View
└── AppBar → VStack, HStack, Text, safe area

Form Components
├── Select → VStack, Text, Modal
├── CheckboxGroup → VStack, HStack, Text
├── RadioGroup → VStack, HStack, Text
└── Input → VStack, Text

Display Components
├── ListItem → VStack, HStack, Text, Pressable
├── Badge → Box, Text
├── Avatar → View, Text
├── Card → Box
└── Chip → Pressable, Text

Navigation Components
├── Tabs → HStack, Pressable, Text
├── Stepper → VStack, HStack, Text
├── Accordion → VStack, Pressable
└── Carousel → ScrollView

Feedback Components
├── Toast → VStack, HStack, Animated
├── Dialog → Modal, VStack, Button
├── ProgressBar → Animated, VStack
├── Loader → Animated, View
└── EmptyState → VStack, Button
```

---

## Total Statistics

```
Total Components: 31
Layout Components: 4
Text Components: 1
Interactive Components: 5
Display Components: 8
Form Components: 5
Navigation Components: 5
Feedback Components: 5
State Components: 1
Utility Components: 2
Modal Components: 2
Progress Components: 2

Lines of Code (Components): ~2,500+
Props Defined: 200+
Features: 50+
```

---

## Next Component Ideas

If you want to extend this system, consider adding:

1. **Menu** - Context menu/popover
2. **Breadcrumbs** - Navigation breadcrumbs
3. **Pagination** - Pagination controls
4. **SearchBar** - Search input
5. **Calendar** - Date picker
6. **TimePicker** - Time selection
7. **Slider** - Range slider
8. **ImagePicker** - Image selection
9. **WebView** - Embedded web content
10. **MapView** - Map integration

---

**All 31 components are production-ready and waiting for you to use them!**
