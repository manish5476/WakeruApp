// Form Management
export { useForm } from './useForm';

// Performance Optimization
export {
  withMemo,
  useMemoized,
  useCallbackMemoized,
  useDebounce,
  useThrottle,
  useLazyComponent,
  useMemoryLeakWarning,
  useRenderCount,
  usePerformanceMonitor,
  useDeepCompareMemo,
  useFlatListOptimization,
  useLazyLoad,
} from './performance';

// Haptic Feedback
export {
  HapticsService,
  useHaptics,
} from './haptics';

export type {
  HapticType,
  HapticOptions,
} from './haptics';

// Gesture Handlers
export {
  useSwipe,
  useLongPress,
  useDoubleTap,
  usePan,
  detectSwipeDirection,
} from './gestures';

// Validation
export {
  validateEmail,
  validatePhone,
  validatePassword,
  validateURL,
  validateCreditCard,
  validateUsername,
  validateField,
  validateForm,
  VALIDATION_RULES,
} from './validation';

// Storage Service
export {
  StorageService,
} from '../services/storage.service';

// Toast Service  
export {
  ToastService,
} from '../services/toast.service';

export default {
  useForm,
  withMemo,
  useMemoized,
  useCallbackMemoized,
  useDebounce,
  useThrottle,
  useLazyComponent,
  useMemoryLeakWarning,
  useRenderCount,
  usePerformanceMonitor,
  useDeepCompareMemo,
  useFlatListOptimization,
  useLazyLoad,
  HapticsService,
  useHaptics,
  useSwipe,
  useLongPress,
  useDoubleTap,
  usePan,
  validateEmail,
  validatePhone,
  validatePassword,
  validateURL,
  validateCreditCard,
  validateUsername,
  validateField,
  validateForm,
  StorageService,
  ToastService,
};
