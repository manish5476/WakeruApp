import { useState, useCallback, useRef } from 'react';
import { GestureResponderEvent } from 'react-native';

interface Position {
  x: number;
  y: number;
}

interface SwipeThresholds {
  velocityThreshold?: number;
  distanceThreshold?: number;
}

interface LongPressConfig {
  duration?: number;
  onLongPress: () => void;
  onPress?: () => void;
}

export const useSwipe = (
  onSwipeLeft?: () => void,
  onSwipeRight?: () => void,
  onSwipeUp?: () => void,
  onSwipeDown?: () => void,
  thresholds: SwipeThresholds = {}
) => {
  const startPosition = useRef<Position>({ x: 0, y: 0 });
  const startTime = useRef<number>(0);

  const { velocityThreshold = 0.3, distanceThreshold = 50 } = thresholds;

  const handleTouchStart = (event: GestureResponderEvent) => {
    const { x, y } = event.nativeEvent;
    startPosition.current = { x, y };
    startTime.current = Date.now();
  };

  const handleTouchEnd = (event: GestureResponderEvent) => {
    const { x, y } = event.nativeEvent;
    const dx = x - startPosition.current.x;
    const dy = y - startPosition.current.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    const timeDiff = Date.now() - startTime.current;
    const velocity = distance / timeDiff;

    if (distance < distanceThreshold || velocity < velocityThreshold) {
      return;
    }

    const isHorizontal = Math.abs(dx) > Math.abs(dy);

    if (isHorizontal) {
      if (dx > 0) {
        onSwipeRight?.();
      } else {
        onSwipeLeft?.();
      }
    } else {
      if (dy > 0) {
        onSwipeDown?.();
      } else {
        onSwipeUp?.();
      }
    }
  };

  return { handleTouchStart, handleTouchEnd };
};

export const useLongPress = ({
  duration = 500,
  onLongPress,
  onPress,
}: LongPressConfig) => {
  const longPressTimeout = useRef<NodeJS.Timeout>();
  const [pressed, setPressed] = useState(false);

  const handlePressIn = useCallback(() => {
    setPressed(true);
    longPressTimeout.current = setTimeout(() => {
      onLongPress();
    }, duration);
  }, [duration, onLongPress]);

  const handlePressOut = useCallback(() => {
    setPressed(false);
    if (longPressTimeout.current) {
      clearTimeout(longPressTimeout.current);
      onPress?.();
    }
  }, [onPress]);

  return {
    onPressIn: handlePressIn,
    onPressOut: handlePressOut,
    pressed,
  };
};

export const useDoubleTap = (onDoubleTap: () => void, delayMs = 300) => {
  const lastTap = useRef<number>(0);

  const handleTap = useCallback(() => {
    const now = Date.now();
    if (now - lastTap.current < delayMs) {
      onDoubleTap();
      lastTap.current = 0;
    } else {
      lastTap.current = now;
    }
  }, [delayMs, onDoubleTap]);

  return { handleTap };
};

export const usePan = (
  onPan?: (dx: number, dy: number) => void,
  onPanEnd?: (dx: number, dy: number, velocityX: number, velocityY: number) => void
) => {
  const startPosition = useRef<Position>({ x: 0, y: 0 });
  const startTime = useRef<number>(0);

  const handlePanStart = (event: GestureResponderEvent) => {
    const { x, y } = event.nativeEvent;
    startPosition.current = { x, y };
    startTime.current = Date.now();
  };

  const handlePanMove = (event: GestureResponderEvent) => {
    const { x, y } = event.nativeEvent;
    const dx = x - startPosition.current.x;
    const dy = y - startPosition.current.y;
    onPan?.(dx, dy);
  };

  const handlePanEnd = (event: GestureResponderEvent) => {
    const { x, y } = event.nativeEvent;
    const dx = x - startPosition.current.x;
    const dy = y - startPosition.current.y;
    const timeDiff = Date.now() - startTime.current || 1;
    const velocityX = dx / timeDiff;
    const velocityY = dy / timeDiff;
    onPanEnd?.(dx, dy, velocityX, velocityY);
  };

  return { handlePanStart, handlePanMove, handlePanEnd };
};
