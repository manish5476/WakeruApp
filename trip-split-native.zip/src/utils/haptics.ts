import { Platform, Vibration, Alert } from 'react-native';

export type HapticType =
  | 'light'
  | 'medium'
  | 'heavy'
  | 'success'
  | 'warning'
  | 'error'
  | 'selection'
  | 'custom';

export interface HapticOptions {
  duration?: number;
  delay?: number;
  repeat?: number;
  repeatDelay?: number;
}

/**
 * Haptics Service - Manage device vibration feedback
 * Works on Android and iOS (requires react-native-haptic-feedback for iOS)
 */
export class HapticsService {
  private static isEnabled = true;
  private static supportedPlatforms = ['android', 'ios'];

  static isAvailable(): boolean {
    return this.supportedPlatforms.includes(Platform.OS) && this.isEnabled;
  }

  static setEnabled(enabled: boolean): void {
    this.isEnabled = enabled;
  }

  static isHapticsEnabled(): boolean {
    return this.isEnabled;
  }

  /**
   * Light haptic feedback - subtle interaction
   */
  static light(): void {
    if (!this.isAvailable()) return;
    Vibration.vibrate(10);
  }

  /**
   * Medium haptic feedback - standard interaction
   */
  static medium(): void {
    if (!this.isAvailable()) return;
    Vibration.vibrate(30);
  }

  /**
   * Heavy haptic feedback - strong notification
   */
  static heavy(): void {
    if (!this.isAvailable()) return;
    Vibration.vibrate(50);
  }

  /**
   * Success haptic - positive feedback pattern
   * Pattern: quick-pause-quick
   */
  static success(): void {
    if (!this.isAvailable()) return;
    Vibration.vibrate([0, 40, 30, 40]);
  }

  /**
   * Warning haptic - alert pattern
   * Pattern: medium-pause-medium
   */
  static warning(): void {
    if (!this.isAvailable()) return;
    Vibration.vibrate([0, 50, 100, 50]);
  }

  /**
   * Error haptic - error pattern
   * Pattern: strong-pause-strong
   */
  static error(): void {
    if (!this.isAvailable()) return;
    Vibration.vibrate([0, 70, 80, 70]);
  }

  /**
   * Selection haptic - selection change
   * Pattern: light-short-pause-light
   */
  static selection(): void {
    if (!this.isAvailable()) return;
    Vibration.vibrate([0, 20, 40, 20]);
  }

  /**
   * Custom haptic pattern
   * @param pattern - Array of on/off durations in milliseconds
   */
  static custom(pattern: number[]): void {
    if (!this.isAvailable()) return;
    Vibration.vibrate(pattern);
  }

  /**
   * Trigger haptic with options
   */
  static trigger(type: HapticType, options?: HapticOptions): void {
    if (!this.isAvailable()) return;

    const delay = options?.delay || 0;
    const repeat = options?.repeat || 1;
    const repeatDelay = options?.repeatDelay || 100;

    const execute = () => {
      for (let i = 0; i < repeat; i++) {
        setTimeout(() => {
          this.executeHaptic(type);
        }, i * repeatDelay);
      }
    };

    if (delay > 0) {
      setTimeout(execute, delay);
    } else {
      execute();
    }
  }

  private static executeHaptic(type: HapticType): void {
    switch (type) {
      case 'light':
        this.light();
        break;
      case 'medium':
        this.medium();
        break;
      case 'heavy':
        this.heavy();
        break;
      case 'success':
        this.success();
        break;
      case 'warning':
        this.warning();
        break;
      case 'error':
        this.error();
        break;
      case 'selection':
        this.selection();
        break;
      default:
        this.medium();
    }
  }

  /**
   * Stop all vibrations
   */
  static stop(): void {
    Vibration.cancel();
  }

  /**
   * Check if haptics are available
   */
  static getCapabilities(): {
    available: boolean;
    platform: string;
    enabled: boolean;
  } {
    return {
      available: this.isAvailable(),
      platform: Platform.OS,
      enabled: this.isEnabled,
    };
  }
}

/**
 * useHaptics - React hook for haptic feedback
 */
export const useHaptics = () => {
  return {
    light: () => HapticsService.light(),
    medium: () => HapticsService.medium(),
    heavy: () => HapticsService.heavy(),
    success: () => HapticsService.success(),
    warning: () => HapticsService.warning(),
    error: () => HapticsService.error(),
    selection: () => HapticsService.selection(),
    custom: (pattern: number[]) => HapticsService.custom(pattern),
    trigger: (type: HapticType, options?: HapticOptions) =>
      HapticsService.trigger(type, options),
    stop: () => HapticsService.stop(),
    isEnabled: () => HapticsService.isHapticsEnabled(),
    setEnabled: (enabled: boolean) => HapticsService.setEnabled(enabled),
    getCapabilities: () => HapticsService.getCapabilities(),
  };
};

export default HapticsService;
