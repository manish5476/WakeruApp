import React, { createContext, useContext, ReactNode, useState, useCallback, useEffect } from 'react';
import { storage } from '@/services/storage.service';

export interface User {
  id: string;
  name: string;
  email: string;
  avatar?: string;
}

export interface AppContextType {
  user: User | null;
  isLoading: boolean;
  setUser: (user: User | null) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (updates: Partial<User>) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUserState] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Initialize user from storage
  useEffect(() => {
    const loadUser = async () => {
      try {
        const storedUser = await storage.getItem<User>('user');
        if (storedUser) {
          setUserState(storedUser);
        }
      } catch (error) {
        console.error('Failed to load user:', error);
      } finally {
        setIsLoading(false);
      }
    };

    loadUser();
  }, []);

  const setUser = useCallback(async (newUser: User | null) => {
    setUserState(newUser);
    if (newUser) {
      await storage.setItem('user', newUser);
    } else {
      await storage.removeItem('user');
    }
  }, []);

  const logout = useCallback(async () => {
    await setUser(null);
  }, [setUser]);

  const updateUser = useCallback(
    async (updates: Partial<User>) => {
      if (!user) return;
      const updatedUser = { ...user, ...updates };
      await setUser(updatedUser);
    },
    [user, setUser]
  );

  const value: AppContextType = {
    user,
    isLoading,
    setUser,
    logout,
    updateUser,
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = (): AppContextType => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within AppProvider');
  }
  return context;
};
