'use client';

import React, { ReactNode, useEffect, useState, useCallback } from 'react';
import { Theme, ThemeMode, ThemePreset } from '@/types/theme';
import { ThemeContext } from '@/design-system/theme/ThemeContext';
import { getThemePreset } from '@/design-system/theme/theme.presets';

interface ThemeProviderProps {
  children: ReactNode;
  defaultPreset?: ThemePreset;
  defaultMode?: ThemeMode;
  persistToLocalStorage?: boolean;
}

export const ThemeProvider: React.FC<ThemeProviderProps> = ({
  children,
  defaultPreset = 'default-light',
  defaultMode = 'light',
  persistToLocalStorage = true,
}) => {
  const [theme, setTheme] = useState<Theme | null>(null);
  const [preset, setPresetState] = useState<ThemePreset>(defaultPreset);
  const [mode, setModeState] = useState<ThemeMode>(defaultMode);

  // Initialize theme from storage or defaults
  useEffect(() => {
    const initializeTheme = () => {
      let initialPreset = defaultPreset;
      let initialMode = defaultMode;

      if (persistToLocalStorage && typeof window !== 'undefined') {
        const storedPreset = localStorage.getItem('tripsplit-theme-preset') as ThemePreset | null;
        const storedMode = localStorage.getItem('tripsplit-theme-mode') as ThemeMode | null;

        if (storedPreset) initialPreset = storedPreset;
        if (storedMode) initialMode = storedMode;
      }

      const currentTheme = getThemePreset(initialPreset);
      const themeModeAdjusted: Theme = {
        ...currentTheme,
        mode: initialMode,
      };

      setTheme(themeModeAdjusted);
      setPresetState(initialPreset);
      setModeState(initialMode);
    };

    initializeTheme();
  }, [defaultPreset, defaultMode, persistToLocalStorage]);

  const handleSetMode = useCallback((newMode: ThemeMode) => {
    setModeState(newMode);
    if (persistToLocalStorage && typeof window !== 'undefined') {
      localStorage.setItem('tripsplit-theme-mode', newMode);
    }
    setTheme((prevTheme) => (prevTheme ? { ...prevTheme, mode: newMode } : null));
  }, [persistToLocalStorage]);

  const handleSetPreset = useCallback((newPreset: ThemePreset) => {
    const newTheme = getThemePreset(newPreset);
    setPresetState(newPreset);
    if (persistToLocalStorage && typeof window !== 'undefined') {
      localStorage.setItem('tripsplit-theme-preset', newPreset);
    }
    setTheme(newTheme);
  }, [persistToLocalStorage]);

  const handleToggleMode = useCallback(() => {
    handleSetMode(mode === 'light' ? 'dark' : 'light');
  }, [mode, handleSetMode]);

  if (!theme) {
    return <>{children}</>;
  }

  const value = {
    theme,
    mode,
    preset,
    setMode: handleSetMode,
    setPreset: handleSetPreset,
    toggleMode: handleToggleMode,
  };

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
};
