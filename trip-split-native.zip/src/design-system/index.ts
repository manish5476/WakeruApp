/**
 * Design System Export Index
 * Central export point for all design system components and utilities
 */

// Components - Layout
export { Box } from './components/Box';
export { VStack, HStack, Spacer } from './components/Stack';

// Components - Typography
export { Text } from './components/Text';

// Components - Navigation
export { AppBar } from './components/AppBar';
export { BottomNavigation } from './components/BottomNavigation';
export { RefreshableScrollView, RefreshableView } from './components/RefreshableScrollView';

// Components - Interactive
export { Button } from './components/Button';
export { Card } from './components/Card';
export { Input } from './components/Input';
export { Badge } from './components/Badge';
export { FAB } from './components/FAB';
export { Modal } from './components/Modal';
export { Switch } from './components/Switch';
export { Divider } from './components/Divider';
export { Chip } from './components/Chip';
export { Avatar } from './components/Avatar';
export { Skeleton } from './components/Skeleton';
export { BottomSheet } from './components/BottomSheet';
export { ListItem } from './components/ListItem';

// Components - Forms
export { Select } from './components/Select';
export { CheckboxGroup } from './components/CheckboxGroup';
export { RadioGroup } from './components/RadioGroup';

// Components - Feedback
export { Toast, ToastContainer } from './components/Toast';
export { Dialog } from './components/Dialog';

// Components - Tier 2
export { ProgressBar } from './components/ProgressBar';
export { Stepper } from './components/Stepper';
export { Accordion } from './components/Accordion';
export { Carousel } from './components/Carousel';
export { Tabs } from './components/Tabs';
export { Rating } from './components/Rating';
export { Loader } from './components/Loader';
export { EmptyState } from './components/EmptyState';
export { Touchable } from './components/Touchable';

// Hooks
export { useTheme } from './hooks/useTheme';
export {
  usePressAnimation,
  useFadeInAnimation,
  useSlideAnimation,
  useRotationAnimation,
  useScaleAnimation,
} from './hooks/useAnimation';
export { useResponsive } from './hooks/useResponsive';

// Theme
export { ThemeProvider } from './theme/ThemeProvider';
export { ThemeContext, AVAILABLE_THEMES } from './theme/ThemeContext';

// Tokens
export {
  SPACING,
  RADIUS,
  SHADOWS,
  OPACITY,
  BORDER_WIDTH,
  ELEVATION,
  GLASS,
  TIMING,
  BREAKPOINTS,
  Z_INDEX,
  COLOR_OPACITY,
  getShadow,
  getSpacing,
  getBorderRadius,
} from './tokens/tokens';

export {
  LIGHT_THEME,
  DARK_THEME,
  AMOLED_THEME,
  GLASS_LIGHT_THEME,
  GLASS_DARK_THEME,
  OCEAN_THEME,
  PRIMITIVES,
  NEUTRAL,
  PRIMARY,
  SECONDARY,
  ACCENT,
  WARNING,
  DANGER,
  INFO,
} from './tokens/colors';

export type {
  SemanticColors,
  ThemeName,
} from './tokens/colors';

// Typography
export {
  FONTS,
  LINE_HEIGHTS,
  TYPOGRAPHY,
  TEXT_PRESETS,
  FONT_WEIGHTS,
  getTypography,
  createCustomTypography,
  getPlatformTypography,
} from './fonts/typography';

// Animations
export {
  SPRING_CONFIGS,
  TIMING_PRESETS,
  EASING_FUNCTIONS,
  animationPresets,
} from './animations/animations';

export type {
  SpringConfig,
  TimingPreset,
  EasingFunction,
} from './animations/animations';

// Icon System
export { IconRegistry } from './icons/IconRegistry';
export type { IconConfig, IconProps } from './icons/IconRegistry';

// Types
export type { ThemeContextType } from './theme/ThemeContext';
