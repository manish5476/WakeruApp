import React, { ReactNode, ErrorInfo } from 'react';
import { View, ScrollView } from 'react-native';
import { Text, Button, VStack } from '@/design-system';
import { useTheme } from '@/design-system/hooks/useTheme';
import { SPACING } from '@/design-system/tokens/tokens';

interface Props {
  children: ReactNode;
  fallback?: (error: Error, retry: () => void) => ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Error caught by ErrorBoundary:', error, errorInfo);
  }

  retry = () => {
    this.setState({ hasError: false, error: null });
  };

  render() {
    if (this.state.hasError && this.state.error) {
      if (this.props.fallback) {
        return this.props.fallback(this.state.error, this.retry);
      }

      return <ErrorBoundaryFallback error={this.state.error} onRetry={this.retry} />;
    }

    return this.props.children;
  }
}

interface ErrorBoundaryFallbackProps {
  error: Error;
  onRetry: () => void;
}

const ErrorBoundaryFallback: React.FC<ErrorBoundaryFallbackProps> = ({ error, onRetry }) => {
  const { colors } = useTheme();

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: colors.surface,
        justifyContent: 'center',
        paddingHorizontal: SPACING.lg,
      }}
    >
      <ScrollView showsVerticalScrollIndicator={false}>
        <VStack gap="lg" align="center">
          <Text
            variant="heading3"
            weight="700"
            color={colors.error}
            textAlign="center"
          >
            Oops! Something went wrong
          </Text>

          <View
            style={{
              backgroundColor: colors.errorContainer,
              borderRadius: 8,
              padding: SPACING.md,
              width: '100%',
            }}
          >
            <Text
              variant="caption"
              color={colors.onErrorContainer}
              style={{ fontFamily: 'monospace' }}
            >
              {error.message}
            </Text>
            {error.stack && (
              <Text
                variant="caption"
                color={colors.onErrorContainer}
                style={{
                  fontFamily: 'monospace',
                  marginTop: SPACING.sm,
                  opacity: 0.7,
                }}
                numberOfLines={5}
              >
                {error.stack}
              </Text>
            )}
          </View>

          <Button
            label="Try Again"
            onPress={onRetry}
            variant="primary"
            width="100%"
          />
        </VStack>
      </ScrollView>
    </View>
  );
};
