/**
 * Settings Screen
 * App preferences and theme selection
 */

import React, { useState } from 'react';
import { ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Box,
  Text,
  Button,
  Card,
  Switch,
  Divider,
  useTheme,
  AVAILABLE_THEMES,
  SPACING,
} from '../../design-system';

export default function SettingsScreen() {
  const { colors, theme, setTheme, isDark } = useTheme();
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(isDark);

  const handleThemeChange = async (newTheme: typeof theme) => {
    await setTheme(newTheme);
  };

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: SPACING.lg }}
      >
        {/* Appearance Section */}
        <Box marginBottom="xl">
          <Text variant="titleLarge" marginBottom="lg">
            Appearance
          </Text>

          <Card padding="lg" marginBottom="lg">
            <Box flexDirection="row" justifyContent="space-between" alignItems="center" marginBottom="md">
              <Text variant="bodyLarge">Current Theme</Text>
              <Text variant="titleSmall" color={colors.primary}>
                {theme}
              </Text>
            </Box>
            <Divider margin="md" />
            <Box gap="sm" marginTop="lg">
              <Text variant="bodySmall" color={colors.textTertiary} marginBottom="md">
                Select a theme:
              </Text>
              <Box gap="sm">
                {AVAILABLE_THEMES.map((themeName) => (
                  <Button
                    key={themeName}
                    onPress={() => handleThemeChange(themeName)}
                    variant={theme === themeName ? 'primary' : 'outline'}
                    fullWidth
                    size="md"
                  >
                    {themeName.charAt(0).toUpperCase() + themeName.slice(1)}
                  </Button>
                ))}
              </Box>
            </Box>
          </Card>
        </Box>

        {/* Preferences Section */}
        <Box marginBottom="xl">
          <Text variant="titleLarge" marginBottom="lg">
            Preferences
          </Text>

          <Card padding="lg">
            <Box flexDirection="row" justifyContent="space-between" alignItems="center" marginBottom="md">
              <Box flex={1}>
                <Text variant="bodyLarge">Notifications</Text>
                <Text variant="bodySmall" color={colors.textTertiary} marginTop="xs">
                  Receive app notifications
                </Text>
              </Box>
              <Switch
                value={notifications}
                onValueChange={setNotifications}
                variant="primary"
              />
            </Box>

            <Divider margin="md" />

            <Box flexDirection="row" justifyContent="space-between" alignItems="center" marginTop="md">
              <Box flex={1}>
                <Text variant="bodyLarge">Dark Mode</Text>
                <Text variant="bodySmall" color={colors.textTertiary} marginTop="xs">
                  {isDark ? 'Enabled' : 'Disabled'}
                </Text>
              </Box>
              <Switch
                value={isDark}
                onValueChange={() => {
                  const newTheme = isDark ? 'light' : 'dark';
                  handleThemeChange(newTheme as any);
                  setDarkMode(!darkMode);
                }}
                variant="secondary"
              />
            </Box>
          </Card>
        </Box>

        {/* Theme Info */}
        <Box marginBottom="xl">
          <Text variant="titleLarge" marginBottom="lg">
            Theme Information
          </Text>

          <Card variant="glass" padding="lg">
            <Box gap="md">
              <Box>
                <Text variant="labelSmall" color={colors.textTertiary} uppercase>
                  Current Mode
                </Text>
                <Text variant="bodyMedium" marginTop="xs">
                  {isDark ? 'Dark Mode' : 'Light Mode'}
                </Text>
              </Box>
              <Box>
                <Text variant="labelSmall" color={colors.textTertiary} uppercase>
                  Theme Name
                </Text>
                <Text variant="bodyMedium" marginTop="xs" color={colors.primary}>
                  {theme}
                </Text>
              </Box>
              <Box>
                <Text variant="labelSmall" color={colors.textTertiary} uppercase>
                  Available Themes
                </Text>
                <Text variant="bodySmall" marginTop="xs">
                  {AVAILABLE_THEMES.length} themes available
                </Text>
              </Box>
            </Box>
          </Card>
        </Box>

        {/* About Section */}
        <Box>
          <Text variant="titleLarge" marginBottom="lg">
            About
          </Text>

          <Card padding="lg" variant="outlined">
            <Box gap="md">
              <Box>
                <Text variant="labelSmall" color={colors.textTertiary} uppercase>
                  App Version
                </Text>
                <Text variant="bodyMedium" marginTop="xs">
                  1.0.0
                </Text>
              </Box>
              <Box>
                <Text variant="labelSmall" color={colors.textTertiary} uppercase>
                  Design System
                </Text>
                <Text variant="bodySmall" marginTop="xs">
                  TripSplit Native Design System v1.0
                </Text>
              </Box>
            </Box>
          </Card>
        </Box>
      </ScrollView>
    </SafeAreaView>
  );
}
