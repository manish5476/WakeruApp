/**
 * Components Screen
 * Showcase of all available components
 */

import React, { useState } from 'react';
import { ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Box,
  Text,
  Button,
  Card,
  Input,
  Badge,
  Switch,
  Chip,
  Avatar,
  Divider,
  Modal,
  BottomSheet,
  useTheme,
  SPACING,
} from '../../design-system';

export default function ComponentsScreen() {
  const { colors } = useTheme();
  const [modalVisible, setModalVisible] = useState(false);
  const [bottomSheetVisible, setBottomSheetVisible] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [switchValue, setSwitchValue] = useState(false);
  const [selectedChips, setSelectedChips] = useState<string[]>(['budget']);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: SPACING.lg }}
      >
        {/* Buttons Section */}
        <Box marginBottom="xl">
          <Text variant="titleLarge" marginBottom="lg">
            Buttons
          </Text>
          <Box gap="md">
            <Button onPress={() => {}} variant="primary" fullWidth>
              Primary Button
            </Button>
            <Button onPress={() => {}} variant="secondary" fullWidth>
              Secondary Button
            </Button>
            <Button onPress={() => {}} variant="outline" fullWidth>
              Outline Button
            </Button>
            <Button onPress={() => {}} variant="ghost" fullWidth>
              Ghost Button
            </Button>
          </Box>
        </Box>

        {/* Badges Section */}
        <Box marginBottom="xl">
          <Text variant="titleLarge" marginBottom="lg">
            Badges
          </Text>
          <Box flexDirection="row" gap="md" flexWrap="wrap">
            <Badge label="Primary" variant="primary" />
            <Badge label="Secondary" variant="secondary" />
            <Badge label="Success" variant="success" />
            <Badge label="Warning" variant="warning" />
            <Badge label="Danger" variant="danger" />
          </Box>
        </Box>

        {/* Cards Section */}
        <Box marginBottom="xl">
          <Text var="titleLarge" marginBottom="lg">
            Cards
          </Text>
          <Box gap="md">
            <Card variant="elevated">
              <Text variant="titleSmall">Elevated Card</Text>
              <Text variant="bodySmall" color={colors.textSecondary} marginTop="sm">
                This is an elevated card with shadow effect
              </Text>
            </Card>
            <Card variant="glass">
              <Text variant="titleSmall">Glass Morphism Card</Text>
              <Text variant="bodySmall" color={colors.textSecondary} marginTop="sm">
                Modern glass effect card
              </Text>
            </Card>
            <Card variant="outlined">
              <Text variant="titleSmall">Outlined Card</Text>
              <Text variant="bodySmall" color={colors.textSecondary} marginTop="sm">
                Card with border outline
              </Text>
            </Card>
          </Box>
        </Box>

        {/* Input Section */}
        <Box marginBottom="xl">
          <Text variant="titleLarge" marginBottom="lg">
            Input Fields
          </Text>
          <Box gap="md">
            <Input
              label="Email"
              placeholder="Enter your email"
              value={inputValue}
              onChangeText={setInputValue}
            />
            <Input
              label="Password"
              placeholder="Enter password"
              secureTextEntry
            />
            <Input
              label="With Error"
              placeholder="This field has error"
              error="This field is required"
            />
          </Box>
        </Box>

        {/* Chips Section */}
        <Box marginBottom="xl">
          <Text variant="titleLarge" marginBottom="lg">
            Chips
          </Text>
          <Box flexDirection="row" gap="md" flexWrap="wrap">
            {['budget', 'travel', 'food', 'fun'].map((chip) => (
              <Chip
                key={chip}
                label={chip}
                selected={selectedChips.includes(chip)}
                onPress={() => {
                  if (selectedChips.includes(chip)) {
                    setSelectedChips(selectedChips.filter((c) => c !== chip));
                  } else {
                    setSelectedChips([...selectedChips, chip]);
                  }
                }}
              />
            ))}
          </Box>
        </Box>

        {/* Avatars Section */}
        <Box marginBottom="xl">
          <Text variant="titleLarge" marginBottom="lg">
            Avatars
          </Text>
          <Box flexDirection="row" gap="md">
            <Avatar name="John Doe" size="md" />
            <Avatar name="Jane Smith" size="md" />
            <Avatar name="Alex Johnson" size="md" />
          </Box>
        </Box>

        {/* Switch Section */}
        <Box marginBottom="xl">
          <Text variant="titleLarge" marginBottom="lg">
            Switches
          </Text>
          <Card padding="lg">
            <Box flexDirection="row" justifyContent="space-between" alignItems="center">
              <Text variant="bodyLarge">Enable Feature</Text>
              <Switch
                value={switchValue}
                onValueChange={setSwitchValue}
                variant="primary"
              />
            </Box>
            <Divider margin="lg" />
            <Box flexDirection="row" justifyContent="space-between" alignItems="center" marginTop="lg">
              <Text variant="bodyLarge">Another Toggle</Text>
              <Switch
                value={!switchValue}
                onValueChange={() => {}}
                variant="secondary"
              />
            </Box>
          </Card>
        </Box>

        {/* Modal Section */}
        <Box marginBottom="xl">
          <Button
            onPress={() => setModalVisible(true)}
            variant="primary"
            fullWidth
          >
            Open Modal
          </Button>
          <Modal
            visible={modalVisible}
            onClose={() => setModalVisible(false)}
            title="Sample Modal"
          >
            <Text variant="bodyMedium" marginBottom="lg">
              This is a modal dialog. Press outside to close.
            </Text>
            <Button
              onPress={() => setModalVisible(false)}
              variant="primary"
              fullWidth
            >
              Close Modal
            </Button>
          </Modal>
        </Box>

        {/* Bottom Sheet Section */}
        <Box marginBottom="xl">
          <Button
            onPress={() => setBottomSheetVisible(true)}
            variant="secondary"
            fullWidth
          >
            Open Bottom Sheet
          </Button>
          <BottomSheet
            visible={bottomSheetVisible}
            onClose={() => setBottomSheetVisible(false)}
            title="Bottom Sheet"
          >
            <Text variant="bodyMedium" marginBottom="lg">
              Swipe down to dismiss or tap outside
            </Text>
            <Button
              onPress={() => setBottomSheetVisible(false)}
              variant="outline"
              fullWidth
            >
              Close
            </Button>
          </BottomSheet>
        </Box>

        {/* Typography Section */}
        <Box marginBottom="xl">
          <Text variant="titleLarge" marginBottom="lg">
            Typography
          </Text>
          <Box gap="md">
            <Text variant="displayLarge">Display Large</Text>
            <Text variant="displaySmall">Display Small</Text>
            <Text variant="headingLarge">Heading Large</Text>
            <Text variant="headingMedium">Heading Medium</Text>
            <Text variant="titleLarge">Title Large</Text>
            <Text variant="bodyLarge">Body Large</Text>
            <Text variant="bodyMedium">Body Medium</Text>
            <Text variant="bodySmall">Body Small</Text>
          </Box>
        </Box>
      </ScrollView>
    </SafeAreaView>
  );
}
