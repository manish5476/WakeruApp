/**
 * Home Screen
 * Main dashboard and entry point
 */

import React, { useState } from 'react';
import { ScrollView, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import {
  Box,
  Text,
  Button,
  Card,
  Badge,
  useTheme,
  SPACING,
} from '../../design-system';

export default function HomeScreen() {
  const { colors } = useTheme();
  const [count, setCount] = useState(0);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.background }}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ padding: SPACING.lg }}
      >
        {/* Header Section */}
        <Box marginBottom="xl">
          <Text variant="displaySmall" marginBottom="md">
            Welcome to TripSplit
          </Text>
          <Text variant="bodyLarge" color={colors.textSecondary}>
            Split your trip expenses easily with our modern app
          </Text>
        </Box>

        {/* Quick Stats */}
        <Box gap="md" marginBottom="xl">
          <Card variant="elevated">
            <Box flexDirection="row" justifyContent="space-between" alignItems="center">
              <Box>
                <Text variant="bodySmall" color={colors.textTertiary}>
                  Total Trips
                </Text>
                <Text variant="headingLarge" marginTop="sm">
                  3
                </Text>
              </Box>
              <Badge label="Active" variant="primary" />
            </Box>
          </Card>

          <Card variant="glass">
            <Box flexDirection="row" justifyContent="space-between" alignItems="center">
              <Box>
                <Text variant="bodySmall" color={colors.textTertiary}>
                  You Owe
                </Text>
                <Text variant="headingLarge" marginTop="sm" color={colors.warning}>
                  $245.50
                </Text>
              </Box>
              <Badge label="Pending" variant="warning" />
            </Box>
          </Card>

          <Card variant="elevated">
            <Box flexDirection="row" justifyContent="space-between" alignItems="center">
              <Box>
                <Text variant="bodySmall" color={colors.textTertiary}>
                  Owed to You
                </Text>
                <Text variant="headingLarge" marginTop="sm" color={colors.accent}>
                  $512.00
                </Text>
              </Box>
              <Badge label="Owed" variant="success" />
            </Box>
          </Card>
        </Box>

        {/* Interactive Demo */}
        <Box marginBottom="xl">
          <Text variant="titleLarge" marginBottom="lg">
            Interactive Demo
          </Text>
          <Card padding="lg" marginBottom="lg">
            <Text variant="bodyMedium" marginBottom="lg" align="center">
              Count: {count}
            </Text>
            <Box flexDirection="row" gap="md">
              <Button
                onPress={() => setCount(count - 1)}
                variant="secondary"
                flex={1}
              >
                Decrease
              </Button>
              <Button
                onPress={() => setCount(count + 1)}
                variant="primary"
                flex={1}
              >
                Increase
              </Button>
            </Box>
          </Card>

          <Box flexDirection="row" gap="md">
            <Button
              onPress={() => setCount(0)}
              variant="outline"
              flex={1}
            >
              Reset
            </Button>
            <Button
              onPress={() => setCount(count * 2)}
              variant="ghost"
              flex={1}
            >
              Double
            </Button>
          </Box>
        </Box>

        {/* Features Section */}
        <Box>
          <Text variant="titleLarge" marginBottom="lg">
            Key Features
          </Text>
          <Box gap="md">
            {[
              { title: 'Easy Splitting', desc: 'Split expenses with friends' },
              { title: 'Multiple Themes', desc: 'Choose your preferred appearance' },
              { title: 'Beautiful UI', desc: 'Modern glass morphism design' },
              { title: 'Lightning Fast', desc: 'Optimized for performance' },
            ].map((feature, index) => (
              <Card key={index} variant="outlined">
                <Text variant="titleSmall">{feature.title}</Text>
                <Text variant="bodySmall" color={colors.textTertiary} marginTop="xs">
                  {feature.desc}
                </Text>
              </Card>
            ))}
          </Box>
        </Box>
      </ScrollView>
    </SafeAreaView>
  );
}
