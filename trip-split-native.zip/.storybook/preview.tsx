import type { Preview } from '@storybook/react-native';
import { ThemeProvider } from '../src/design-system';
import React from 'react';

const preview: Preview = {
  parameters: {
    controls: {
      matchers: {
        color: /(background|color)$/i,
        date: /Date$/,
      },
    },
    viewport: {
      defaultViewport: 'iphone12',
    },
  },
  decorators: [
    (Story) => (
      <ThemeProvider initialTheme="light">
        <Story />
      </ThemeProvider>
    ),
  ],
};

export default preview;
