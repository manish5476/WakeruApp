# TripSplit Native

A production-grade React Native application with an enterprise-quality design system featuring glass morphism, multiple themes, and comprehensive UI components.

## Overview

TripSplit Native is built with:
- **React Native CLI** (no Expo APIs)
- **React Navigation** for routing
- **React Native Reanimated** for animations
- **React Native Gesture Handler** for gestures
- **TypeScript** for type safety
- **AsyncStorage** for persistence

## Project Structure

```
src/
├── design-system/              # Complete design system
│   ├── components/            # 13+ UI components
│   │   ├── Box.tsx           # Base layout component
│   │   ├── Text.tsx          # Semantic text component
│   │   ├── Button.tsx        # Interactive button
│   │   ├── Card.tsx          # Surface component
│   │   ├── Input.tsx         # Text input field
│   │   ├── Badge.tsx         # Badge/tag component
│   │   ├── FAB.tsx           # Floating action button
│   │   ├── Modal.tsx         # Modal dialog
│   │   ├── Switch.tsx        # Toggle switch
│   │   ├── Divider.tsx       # Visual separator
│   │   ├── Chip.tsx          # Selection chip
│   │   ├── Avatar.tsx        # User avatar
│   │   ├── Skeleton.tsx      # Loading placeholder
│   │   └── BottomSheet.tsx   # Bottom sheet panel
│   ├── hooks/                 # Custom React hooks
│   │   ├── useTheme.ts       # Theme access
│   │   ├── useAnimation.ts   # Animation utilities
│   │   └── useResponsive.ts  # Responsive design
│   ├── theme/                 # Theme system
│   │   ├── ThemeProvider.tsx # Theme provider wrapper
│   │   └── ThemeContext.ts   # Theme context
│   ├── tokens/                # Design tokens
│   │   ├── tokens.ts         # Spacing, radius, shadows
│   │   └── colors.ts         # Color system & themes
│   ├── fonts/                 # Typography system
│   │   └── typography.ts     # Typography scales & presets
│   ├── animations/            # Animation system
│   │   └── animations.ts     # Animation presets
│   └── index.ts              # Main export file
├── screens/                   # App screens
│   ├── HomeScreen/           # Main dashboard
│   ├── SettingsScreen/       # Settings & theme selector
│   └── ComponentsScreen/     # Component showcase
├── navigation/               # Navigation configuration
│   └── RootNavigator.tsx     # Tab navigation setup
├── types/                    # TypeScript type definitions
├── utils/                    # Utility functions
└── services/                 # Business logic & APIs

App.tsx                        # Root component
index.js                       # Entry point
```

## Design System Features

### Typography System
- **14 typography variants** (Display, Heading, Title, Body, Label)
- **2 font families** (Inter for body, Space Grotesk for display)
- **Complete line height and letter spacing** configuration
- **Platform-specific adjustments** for iOS/Android

### Color System
- **6 production-ready theme presets:**
  - Light (default)
  - Dark
  - AMOLED (for OLED screens)
  - Glass Light
  - Glass Dark
  - Ocean

- **Semantic color tokens:**
  - Surfaces (background, surface, surfaceAlt, surfaceInverted)
  - Glass effects (glassLight, glassMedium, glassDark)
  - Text (text, textSecondary, textTertiary, textInverted)
  - Interactive states
  - Component colors (primary, secondary, accent, warning, danger, info)
  - Border and overlay colors

### Design Tokens
- **Spacing system** (8px base with 7 levels)
- **Border radius** (4px to 999px with 7 presets)
- **Shadow system** (4 elevation levels)
- **Opacity scale** (10 levels: 0-100%)
- **Timing presets** (micro to glacial)
- **Breakpoints** for responsive design
- **Z-index layers** for layering

### Animation System
- **Spring configurations** (gentle, quick, bouncy, stiff, molasses)
- **Motion presets** (micro, fast, normal, slow, slower, glacial)
- **Custom animation hooks:**
  - usePressAnimation - Button press feedback
  - useFadeInAnimation - Fade-in transitions
  - useSlideAnimation - Slide-in/out animations
  - useRotationAnimation - Rotation effects
  - useScaleAnimation - Scale transformations

### UI Components (13+)
1. **Box** - Flexible layout component
2. **Text** - Semantic typography component
3. **Button** - Multi-variant button (primary, secondary, outline, ghost)
4. **Card** - Surface component (elevated, filled, outlined, glass)
5. **Input** - Text input with validation
6. **Badge** - Small label component
7. **FAB** - Floating action button
8. **Modal** - Dialog overlay
9. **Switch** - Toggle switch
10. **Divider** - Visual separator
11. **Chip** - Selection chip
12. **Avatar** - User profile picture
13. **Skeleton** - Loading placeholder
14. **BottomSheet** - Bottom panel

## Usage Examples

### Theme Provider Setup
```tsx
import { ThemeProvider } from './src/design-system';
import App from './src/screens/HomeScreen';

export default function Root() {
  return (
    <ThemeProvider initialTheme="light">
      <App />
    </ThemeProvider>
  );
}
```

### Using Components
```tsx
import { Box, Text, Button, useTheme } from './src/design-system';

export default function MyScreen() {
  const { colors } = useTheme();

  return (
    <Box padding="lg" bg={colors.background}>
      <Text variant="headingLarge">Welcome</Text>
      <Button onPress={() => {}} variant="primary">
        Click Me
      </Button>
    </Box>
  );
}
```

### Theme Switching
```tsx
import { useTheme, AVAILABLE_THEMES } from './src/design-system';

export default function ThemeSelector() {
  const { theme, setTheme } = useTheme();

  return (
    <Box>
      {AVAILABLE_THEMES.map((themeName) => (
        <Button
          key={themeName}
          onPress={() => setTheme(themeName)}
          variant={theme === themeName ? 'primary' : 'outline'}
        >
          {themeName}
        </Button>
      ))}
    </Box>
  );
}
```

### Animations
```tsx
import { usePressAnimation } from './src/design-system/hooks/useAnimation';
import Animated from 'react-native-reanimated';

export default function AnimatedButton() {
  const { onPressIn, onPressOut, animatedStyle } = usePressAnimation();

  return (
    <Animated.View style={animatedStyle}>
      <Pressable onPressIn={onPressIn} onPressOut={onPressOut}>
        <Text>Press Me</Text>
      </Pressable>
    </Animated.View>
  );
}
```

## Installation & Setup

### Prerequisites
- Node.js 16+ 
- npm or yarn
- Xcode (for iOS development)
- Android Studio (for Android development)

### Install Dependencies
```bash
npm install
# or
yarn install
```

### Running on iOS
```bash
npm run ios
# or
yarn ios
```

### Running on Android
```bash
npm run android
# or
yarn android
```

### Start Metro Bundler
```bash
npm start
# or
yarn start
```

## Available Scripts

- `npm run ios` - Run on iOS simulator
- `npm run android` - Run on Android emulator
- `npm start` - Start Metro bundler
- `npm test` - Run tests

## Key Dependencies

```json
{
  "react": "^18.2.0",
  "react-native": "^0.73.0",
  "react-native-reanimated": "^3.6.0",
  "react-native-gesture-handler": "^2.14.0",
  "@react-navigation/native": "^6.1.0",
  "@react-navigation/bottom-tabs": "^6.5.0",
  "@react-navigation/native-stack": "^6.9.0",
  "@react-native-async-storage/async-storage": "^1.21.0"
}
```

## Theme Presets Details

### Light Theme
- Clean, minimal design
- High contrast for readability
- Perfect for daytime use

### Dark Theme
- Easy on the eyes in low light
- Standard dark colors
- Professional appearance

### AMOLED Theme
- Optimized for OLED screens
- Pure black background
- Battery-efficient

### Glass Light
- Frosted glass effect
- Translucent surfaces
- Modern aesthetic

### Glass Dark
- Dark glass morphism
- Blurred background interaction
- Contemporary design

### Ocean Theme
- Cool blue color palette
- Calming atmosphere
- Professional tech theme

## Accessibility

- Semantic HTML elements (Text, Button components)
- Color contrast compliance
- Touch target sizes (minimum 44x44pt)
- Screen reader support
- Accessible button labels

## Performance

- Memoized components
- Lazy rendering with Reanimated
- Optimized animations
- Efficient re-renders
- AsyncStorage caching

## Best Practices

1. **Use the design system components** - Never use raw View/Text
2. **Follow the spacing scale** - Use SPACING tokens
3. **Leverage themes** - Use useTheme hook for dynamic colors
4. **Optimize animations** - Use Reanimated for 60fps animations
5. **Type everything** - Full TypeScript coverage

## Screens Included

### Home Screen
- Dashboard with trip statistics
- Interactive counter demo
- Feature showcase
- Card component showcase

### Settings Screen
- Theme selector (6 themes)
- Preference toggles
- Theme information display
- App version info

### Components Screen
- All component variations
- Interactive examples
- Typography showcase
- Modal and BottomSheet demos

## Future Enhancements

- [ ] Swipe gestures for navigation
- [ ] Advanced animations library
- [ ] Form validation utilities
- [ ] Data persistence layer
- [ ] API integration utilities
- [ ] Testing utilities
- [ ] Accessibility enhanced components

## License

MIT

## Support

For issues, questions, or suggestions, please refer to the project documentation or contact the development team.

---

**TripSplit Native v1.0.0** - Built with ❤️ for production apps
