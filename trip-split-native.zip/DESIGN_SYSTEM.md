# TripSplit Native Design System

A comprehensive, enterprise-grade design system for the TripSplit Native React Native CLI application.

## Overview

This design system is comparable to world-class systems from Airbnb, Stripe, Shopify, Apple, Notion, Linear, and Discord. It provides a complete foundation for building premium, minimal, elegant, glassmorphic, and modern interfaces.

### Key Characteristics

- **Premium** - High-end visual polish and attention to detail
- **Minimal** - Clean, uncluttered interfaces with purposeful spacing
- **Elegant** - Sophisticated and refined aesthetic
- **Glassmorphic** - Modern frosted glass effect components
- **Modern** - Contemporary design patterns and interactions
- **Native** - Feels like a system application, not a typical React Native app
- **Extremely Polished** - Every detail is crafted to perfection

## Architecture

### Directory Structure

```
src/design-system/
├── animations/          # Animation helpers and presets
├── components/          # Component foundation APIs
├── fonts/              # Typography configuration
├── hooks/              # Design system hooks
├── icons/              # Icon system and provider
├── layouts/            # Layout helpers and components
├── motion/             # Motion presets and timing
├── providers/          # React context providers
├── surfaces/           # Surface system definitions
├── theme/              # Theme engine and presets
├── tokens/             # Design tokens (colors, spacing, etc.)
└── utils/              # Utility helpers
```

## Core Systems

### 1. Theme Engine

Complete theme architecture with runtime switching support.

**Files:**
- `src/design-system/theme/ThemeContext.ts` - React context
- `src/design-system/providers/ThemeProvider.tsx` - Theme provider component
- `src/design-system/theme/theme.presets.ts` - All theme presets

**Usage:**

```tsx
import { ThemeProvider, useTheme } from '@/design-system';

export default function App() {
  return (
    <ThemeProvider defaultPreset="default-light">
      <YourApp />
    </ThemeProvider>
  );
}

function MyComponent() {
  const { theme, setPreset, toggleMode } = useTheme();
  return (
    <View style={{ backgroundColor: theme.colors.background }}>
      {/* Component code */}
    </View>
  );
}
```

### 2. Theme Presets

13 production-ready theme presets included:

- **default-light** - Clean light mode
- **default-dark** - Classic dark mode
- **amoled** - AMOLED-optimized dark mode
- **glass-light** - Glass-morphic light theme
- **glass-dark** - Glass-morphic dark theme
- **midnight** - Deep indigo/purple theme
- **ocean** - Cool blue/cyan theme
- **aurora** - Pink/purple gradient theme
- **sunset** - Warm orange/gold theme
- **forest** - Green natural theme
- **slate** - Neutral gray theme
- **minimal** - Ultra-minimal black/white
- **luxury-black** - Gold accents on black

### 3. Design Tokens

Comprehensive token system covering:

**Files:**
- `src/design-system/tokens/base.tokens.ts` - Base tokens (spacing, radius, typography, etc.)
- `src/design-system/tokens/glass.tokens.ts` - Glass morphism presets

**Token Categories:**

```typescript
// Colors - Primary, secondary, accents, status, neutral, text
theme.colors

// Typography - 16 semantic scales
theme.typography.body
theme.typography.headingL
theme.typography.displayXL

// Spacing - 10 scale levels
theme.spacing.xs through theme.spacing.xl6

// Radius - 7 corner sizes
theme.radius.none through theme.radius.full

// Shadows - 7 elevation levels
theme.shadows.xs through theme.shadows.xl2

// Glass - 11 glassmorphic presets
theme.glass.ultraThin
theme.glass.regular
theme.glass.modal
// ... and more

// Breakpoints - 6 responsive sizes
theme.breakpoints.xs through theme.breakpoints.xl2

// Elevation - Visual stacking order
// Opacity - Transparency levels
// Icon Sizes - Standard icon dimensions
```

### 4. Glassmorphism System

Complete glass effect system with multiple intensity levels:

**File:** `src/design-system/tokens/glass.tokens.ts`

**Presets:**
- `ultraThin` - Minimal blur, 30% opacity
- `thin` - Light blur, 40% opacity
- `regular` - Balanced blur, 50% opacity
- `thick` - Heavy blur, 60% opacity
- `frosted` - Maximum blur, 70% opacity
- `floating` - Floating with shadow
- `navigation` - For nav bars
- `overlay` - Semi-transparent overlay
- `bottomSheet` - Bottom sheet glass
- `modal` - Modal glass
- `sidebar` - Sidebar glass

**Usage:**

```tsx
import { glassStyle, useTheme } from '@/design-system';

function GlassCard() {
  const { theme } = useTheme();
  
  return (
    <View style={glassStyle(theme, 'regular')}>
      {/* Content */}
    </View>
  );
}
```

### 5. Typography System

16 semantic typography scales for complete hierarchy:

**File:** `src/design-system/tokens/base.tokens.ts`

```typescript
// Display
displayXL  // 56px
displayL   // 48px
displayM   // 40px

// Headings
headingXL  // 32px
headingL   // 28px
headingM   // 24px
headingS   // 20px

// Body
title      // 18px
subtitle   // 16px
bodyXL     // 16px
body       // 14px
bodySmall  // 12px

// Functional
caption    // 12px
label      // 12px
overline   // 10px
code       // 13px
numeric    // 14px
```

### 6. Motion System

Comprehensive animation presets with multiple categories:

**File:** `src/design-system/motion/motion.presets.ts`

**Timing:**
- `instant` - 0ms
- `quick` - 100ms
- `fast` - 150ms
- `normal` - 300ms
- `slow` - 500ms
- `slowest` - 800ms

**Easing:**
- Linear and standard easing curves
- Cubic bezier functions for smooth motion
- Quad, cubic, quart, quint, expo, circ variants

**Spring Configs:**
- `lazy` - Relaxed spring motion
- `gentle` - Smooth entry/exit
- `normal` - Standard spring
- `wobbly` - Playful bounce
- `snappy` - Quick response
- `molasses` - Slow, heavy motion

**Animation Presets:**
- Entrance animations (fadeIn, slideInUp, scaleIn, popIn, etc.)
- Exit animations (fadeOut, slideOutDown, etc.)
- Component animations (buttonPress, cardLift, ripple, pulse, etc.)
- Transition animations (crossFade, modalEnter, navigationPush, etc.)
- Gesture animations (pan, pinch, rotate, swipe)

### 7. Surface System

Reusable surfaces for consistent component styling:

**File:** `src/design-system/surfaces/surface.system.ts`

**Surface Types:**
- `primary` - Main surface
- `secondary` - Alternative surface
- `card` - Card component surface
- `elevatedCard` - Elevated card surface
- `glass` - Glassmorphic surface
- `floatingGlass` - Elevated glass
- `navigationGlass` - Navigation glass
- `bottomSheet` - Bottom sheet surface
- `modal` - Modal surface
- `overlay` - Semi-transparent overlay
- `input` - Input field surface
- `subtle` - Minimal surface
- `interactive` - Primary action surface
- `accent` - Accent surface
- `success/warning/error` - Status surfaces
- `disabled` - Disabled state surface

**Usage:**

```tsx
import { createSurfaceSystem, useTheme } from '@/design-system';

function Card() {
  const { theme } = useTheme();
  const surfaces = createSurfaceSystem(theme);
  
  return (
    <View style={surfaces.card}>
      {/* Content */}
    </View>
  );
}
```

### 8. Layout System

Flexible layout helpers for responsive design:

**File:** `src/design-system/layouts/layout.helpers.ts`

**Helpers:**
- `flexCenter` - Center content
- `flexRow/flexCol` - Row/column layouts
- `spaceBetween/spaceAround/spaceEvenly` - Distribution
- `fill` - Flex 1
- `absoluteFill` - Cover parent
- `stack/hStack` - Semantic stacking
- `grid` - Grid layout
- `size/width/height` - Dimensions
- Responsive padding/margin
- Sticky positioning
- Z-index management

### 9. Icon System

Swappable icon system with registry pattern:

**File:** `src/design-system/icons/IconProvider.tsx`

**Features:**
- Dynamic icon registration
- Icon provider with context
- Icon wrapper component
- Registry manager for app-wide management
- Support for icon libraries (swap providers later)

**Usage:**

```tsx
import { IconProvider, Icon, iconSizes } from '@/design-system';

// Wrap app
<IconProvider initialIcons={iconLibrary}>
  <YourApp />
</IconProvider>

// Use in components
<Icon name="heart" size={iconSizes.lg} color="#FF006E" />
```

### 10. Animation Helpers

Helper functions for creating animations:

**File:** `src/design-system/animations/animation.helpers.ts`

**Functions:**
- `createPressAnimation` - Button press effect
- `createHoverAnimation` - Hover state
- `createRippleAnimation` - Material ripple
- `createBounceAnimation` - Bounce effect
- `createPulseAnimation` - Pulsing effect
- `createLoadingAnimation` - Spinning loader
- `createSkeletonAnimation` - Shimmer effect
- `createFloatingAnimation` - Floating element
- `createModalOpenAnimation` - Modal entrance
- `createStaggerAnimation` - Stagger multiple items
- `chainAnimations` - Sequential animations
- And many more...

### 11. Styling Helpers

Utility functions for style creation:

**File:** `src/design-system/utils/styling.helpers.ts`

**Utilities:**
- `createStyles` - Type-safe style creation
- `createVariant` - Component variants
- `mergeStyles` - Combine styles
- `responsive` - Breakpoint-based styles
- `glassStyle` - Glass morphism
- `surfaceStyle` - Surface styling
- `shadowStyle` - Shadow application
- `typography` - Typography styles
- `animation` - Animation styles
- `color` - Color styling
- `radius` - Border radius
- And more...

### 12. Utility Helpers

General-purpose utility functions:

**File:** `src/design-system/utils/utility.helpers.ts`

**Categories:**

**Color Helpers:**
- `hexToRgb` / `rgbToHex` - Color conversion
- `lighten` / `darken` - Color manipulation
- `getContrastColor` - White or black
- `createPalette` - Color palette generation

**Typography Helpers:**
- `truncate` - Text truncation
- `pxToRem` / `remToPx` - Unit conversion
- `lineHeightMultiplier` - Line height calculation

**Responsive Helpers:**
- `isBreakpoint` - Check breakpoint
- `getActiveBreakpoint` - Get current breakpoint
- `createMediaQuery` - Generate media queries

**Accessibility Helpers:**
- `meetsWCAG_AA` - Contrast compliance
- `getReadableTextColor` - Text color selection

**Performance Helpers:**
- `debounce` - Debounce function
- `throttle` - Throttle function
- `memoize` - Memoize results

### 13. Theme Hooks

Custom hooks for accessing design system:

**File:** `src/design-system/hooks/useThemeHooks.ts`

**Hooks:**
- `useTheme()` - Get full theme
- `useColors()` - Get color tokens
- `useTypography()` - Get typography
- `useSpacing()` - Get spacing tokens
- `useRadius()` - Get radius tokens
- `useElevation()` - Get elevation tokens
- `useGlass()` - Get glass tokens
- `useShadow()` - Get shadow tokens
- `useBreakpoints()` - Get breakpoints
- `useMotion()` - Get motion configs
- `useOpacity()` - Get opacity tokens
- `useSemanticColors()` - Get semantic colors
- `useThemeMode()` - Get/set theme mode

### 14. Component Foundation

Base interfaces and types for all components:

**File:** `src/design-system/components/component.foundation.ts`

**Base Props:**
- `PrimitiveProps` - Basic component props
- `InteractiveProps` - Interactive components
- `VariantProps` - Variant system
- `SurfaceProps` - Surface components

**Component Props:**
- `ButtonProps` - Button interface
- `InputProps` - Input interface
- `CardProps` - Card interface
- `ModalProps` - Modal interface
- `StackProps` - Stack/layout interface
- And 10+ more...

**Component System:**
- `ComponentComposition` - Compound components
- `ComponentState` - State management
- `ComponentAnimationConfig` - Animation config
- `AccessibilityConfig` - A11y config
- `ComponentAPI` - Complete API definition

## Getting Started

### 1. Wrap Your App

```tsx
import { ThemeProvider } from '@/design-system';

export default function App() {
  return (
    <ThemeProvider defaultPreset="default-light">
      <MainApp />
    </ThemeProvider>
  );
}
```

### 2. Use Theme in Components

```tsx
import { useTheme, useColors, typography } from '@/design-system';
import { View, Text } from 'react-native';

function MyComponent() {
  const { theme } = useTheme();
  const colors = useColors();
  
  return (
    <View style={{ 
      backgroundColor: colors.background,
      padding: theme.spacing.md,
      borderRadius: theme.radius.lg,
    }}>
      <Text style={typography(theme.typography.body)}>
        Hello Design System!
      </Text>
    </View>
  );
}
```

### 3. Access All Systems

```tsx
import {
  useTheme,
  useColors,
  useTypography,
  useSpacing,
  useGlass,
  useMotion,
  useBreakpoints,
  colorHelpers,
  layoutHelpers,
  createStyles,
  glassStyle,
  createSurfaceSystem,
} from '@/design-system';
```

## Best Practices

### Token First
Always use design tokens instead of hardcoding values. This ensures consistency and enables theme switching.

```tsx
// ✅ Good
<View style={{ padding: theme.spacing.md }}>

// ❌ Bad
<View style={{ padding: 12 }}>
```

### Semantic Colors
Use semantic colors for meaning, not specific brand colors.

```tsx
// ✅ Good
color: colors.success
color: colors.error
color: colors.warning

// ❌ Bad
color: '#10B981'
color: '#EF4444'
```

### Responsive Layouts
Use layout helpers for responsive design instead of media queries.

```tsx
// ✅ Good
import { layoutHelpers } from '@/design-system';
style={layoutHelpers.flexCenter()}

// ❌ Bad
style={{ display: 'flex', justifyContent: 'center' }}
```

### Animation Constants
Use motion presets for consistent animation timing.

```tsx
// ✅ Good
duration: motionTimings.normal
easing: motionEasing.easeOutCubic

// ❌ Bad
duration: 300
easing: 'ease-out'
```

### Glass Morphism
Use the glass system for modern, layered interfaces.

```tsx
import { glassStyle, useTheme } from '@/design-system';

style={glassStyle(theme, 'regular')}
```

## Customization

### Creating Custom Theme

```tsx
import { Theme } from '@/design-system';

const customTheme: Theme = {
  mode: 'light',
  preset: 'custom',
  colors: { /* custom colors */ },
  typography: { /* custom typography */ },
  // ... all token categories
};
```

### Creating Custom Surface

```tsx
import { createSurfaceSystem, useTheme } from '@/design-system';

function MyComponent() {
  const { theme } = useTheme();
  const surfaces = createSurfaceSystem(theme);
  
  const customSurface = {
    ...surfaces.card,
    backgroundColor: theme.colors.accent,
  };
  
  return <View style={customSurface} />;
}
```

### Registering Icons

```tsx
import { IconProvider, IconRegistryManager } from '@/design-system';

const manager = IconRegistryManager.getInstance();

manager.register('myIcon', MyIconComponent);
manager.registerBatch({ icon1, icon2, icon3 });
```

## Performance Optimization

### Memoization

The design system is optimized for performance:
- All hooks use `useMemo` to prevent unnecessary rerenders
- Theme context is properly structured for isolation
- Utility functions are memoized when beneficial

### Theme Switching

Switching themes is instant and efficient:

```tsx
const { setPreset, setMode } = useTheme();

// Switch theme preset
setPreset('glass-dark');

// Toggle light/dark
toggleMode();
```

## Accessibility

All components support accessibility features:

```typescript
// Accessibility props available on all components
accessibilityLabel
accessibilityRole
accessibilityHint
accessible

// WCAG compliance helpers
meetsWCAG_AA(foreground, background)
getReadableTextColor(backgroundColor)
```

## Resources

- **Theme Documentation**: See `src/design-system/theme/`
- **Component APIs**: See `src/design-system/components/`
- **Motion System**: See `src/design-system/motion/`
- **Type Definitions**: See `src/types/theme.ts`

## Version

Design System Version: 1.0.0
Last Updated: 2024
Built for: TripSplit Native (React Native CLI)

---

This design system provides everything needed to build world-class, premium interfaces with React Native CLI. All components, hooks, and utilities are production-ready and can be used immediately to start building the TripSplit Native application.
